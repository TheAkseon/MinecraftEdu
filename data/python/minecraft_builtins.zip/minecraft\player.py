"""The player actor.
"""

from __future__ import annotations

import json
import logging
import typing

from minecraft import enums
from minecraft._builtins import execute_command, MinecraftError
from minecraft.location import as_loc, LocationType

__all__ = ["Player"]


LOG = logging.getLogger(__name__)


class Player:
    def __init__(self, name: str = None, key: str = None):
        if not name:
            self._key = key or "@s"
        else:
            self._key = f'@p[name="{name}"]'

    @property
    def position(self) -> LocationType:
        """Gets or sets the position of the player.
        """
        r = execute_command("querytarget", self._key).result()
        try:
            p = json.loads(r["body"]["details"])[0]["position"]
        except (json.JSONDecodeError, LookupError):
            LOG.error("Invalid response from querytarget command", exc_info=True)
            raise MinecraftError("Cannot get position")
        return as_loc(p["x"], p["y"], p["z"])

    @position.setter
    def position(self, value: LocationType):
        self.teleport(value)

    def say(self, *message):
        """Say something on behalf of the player.

        If you pass multiple things, they will be joined with spaces.
        """
        if not message:
            return

        execute_command(
            "execute", self._key, "~ ~ ~", "say", " ".join(map(str, message))
        ).wait()

    def whisper(self, *message):
        """Whisper something to a player.

        If you pass multiple things, they will be joined with spaces.
        """
        if not message:
            return

        execute_command("tell", self._key, " ".join(map(str, message))).wait()

    def give(
        self,
        item: enums.Giveable,
        count: int,
        slot_number: int = None,
        slot: str = None,
    ):
        """Give the player one or more items.
        """
        item_name, item_data, item_components = enums.Giveable.name_to_name_data_components(
            item
        )
        if slot_number is None:
            execute_command(
                "give", self._key, item_name, count, item_data, item_components
            ).wait()
            return
        if not slot:
            if slot_number <= 8:
                slot = "slot.hotbar"
            else:
                slot_number -= 9
                slot = "slot.inventory"

        execute_command(
            "replaceitem",
            "entity",
            self._key,
            slot,
            slot_number,
            item_name,
            count,
            item_data,
            item_components,
        ).wait()

    def clear_inventory(self):
        """Clear the player's inventory.
        """
        try:
            execute_command("clear", self._key).wait()
        except MinecraftError as ex:
            # Inventory is already empty
            if ex.code == 0x80020000:
                return
            raise

    def look_at(self, location: LocationType):
        """Makes the player look in a certain direction.
        """
        self.teleport("~ ~ ~", location)

    def turn(self, direction: enums.TurnDirection):
        """Makes the player turn in a certain direction.
        """
        d = enums.TurnDirection.name_to_name(direction)
        if d == enums.TurnDirection.LEFT:
            self.teleport("~ ~ ~", "^-1 ^ ^")
        elif d == enums.TurnDirection.RIGHT:
            self.teleport("~ ~ ~", "^1 ^ ^")

    def teleport(self, location: LocationType, facing: LocationType = None):
        """Teleports a player to a new location.
        """
        if facing:
            execute_command(
                "teleport", self._key, as_loc(location), "facing", as_loc(facing)
            ).wait()
        else:
            execute_command("teleport", self._key, as_loc(location)).wait()

    def ability(self, ability: enums.Ability, grant: bool = True):
        """Grants (or removes) an ability to the player.
        """
        execute_command(
            "ability", self._key, enums.Ability.name_to_name(ability), grant
        ).wait()

    def gamemode(self, mode: enums.GameMode):
        """Puts a player in a certain game mode.
        """
        execute_command("gamemode", enums.GameMode.name_to_name(mode), self._key).wait()

    def remove(self):
        """Removes the player.
        """
        execute_command("remove", self._key).wait()
        
    def kill(self):
        """Kills the player.
        """
        execute_command("kill", self._key).wait()

    def clear_effect(self, effect: enums.Effect = None):
        """Clears an effect from the player.

        If effect is omitted, clears all effects.
        """
        if not effect:
            execute_command("effect", self._key, "clear").wait()
        else:
            # Specifying a duration of 0 seconds should cancel the effect
            execute_command(
                "effect", self._key, enums.Effect.name_to_name(effect), 0
            ).wait()

    def add_effect(
        self,
        effect: enums.Effect,
        seconds: int = 30,
        amplifier: int = 1,
        hide_particles: bool = False,
    ):
        """Adds an effect to the player.
        """
        execute_command(
            "effect",
            self._key,
            enums.Effect.name_to_name(effect),
            seconds,
            amplifier,
            hide_particles,
        ).wait()

    def enchant(self, enchantment: enums.Enchantment, level: int = 1):
        """Enchants the item currently held by the player.
        """
        execute_command(
            "enchant", self._key, enums.Enchantment.name_to_name(enchantment), level
        ).wait()

    def give_experience(self, xp: int):
        """Gives the player the specified amount of experience.
        """
        execute_command("experience", xp, self._key).wait()

    def give_levels(self, levels: int):
        """Gives or removes a number of levels to or from the player.
        """
        execute_command("experience", f"{levels}L", self._key).wait()

    def clear_levels(self):
        """Removes all levels from the player.
        """
        execute_command("experience", "-2147483648L", self._key).wait()

    def play_sound(
        self,
        sound: str,
        location: LocationType = None,
        volume: float = 1.0,
        pitch: float = 1.0,
        minimum_volume: float = 0.0,
    ):
        """Plays the specified sound to a player or at a location.
        """
        if location is None:
            location = "~ ~ ~"
        execute_command(
            "playsound",
            sound,
            self._key,
            as_loc(location),
            volume,
            pitch,
            minimum_volume,
        ).wait()

    def show_title(
        self,
        title: str = None,
        subtitle: str = None,
        actionbar: str = None,
        fade_in: float = 10,
        stay: float = 70,
        fade_out: float = 20,
    ):
        """Displays the specified title to the player.
        """
        tasks = []
        k = self._key
        tasks.append(execute_command("title", k, "reset"))
        tasks.append(execute_command("title", k, "times", fade_in, stay, fade_out))
        if title:
            tasks.append(execute_command("title", k, "title", title))
        if subtitle:
            tasks.append(execute_command("title", k, "subtitle", subtitle))
        if actionbar:
            tasks.append(execute_command("title", k, "actionbar", actionbar))
        for t in tasks:
            t.wait(delay=0.0)

    def clear_title(self):
        """Clears the currently visible title.
        """
        execute_command("title", self._key, "clear").wait()
