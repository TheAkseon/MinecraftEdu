import unittest

from .support import command_result, debug_records

import minecraft._builtins as mc_builtin
import minecraft.enums as mc_enum
import minecraft.event as mc_event


def is_event(k):
    if k.startswith("_") or k == "GenericEvent":
        return False
    v = getattr(mc_event, k)
    return isinstance(v, type) and issubclass(v, mc_event._BaseEvent)


class TestEvent(unittest.TestCase):
    def test_all_exported(self):
        # Verify all event classes are in __all__
        expected = {k for k in dir(mc_event) if is_event(k)}
        actual = set(mc_event.__all__) & expected
        self.assertSetEqual(expected, actual)

    def test_all_in_enum(self):
        # Verify all event classes are in the enum
        expected = set(mc_enum.Event._names)
        actual = {k[:-5].upper() for k in dir(mc_event) if is_event(k)}
        self.assertSetEqual(expected, actual)

    def test_bound_event(self):
        # Verify that an event bound to a class behaves correctly

        class MyClass:
            @mc_event.on_event("player travelled", add=False)
            def travel(self, location, mode, distance):
                return (self, location, mode, distance)

        mc = MyClass()
        travel = mc.travel
        with debug_records(mc_builtin.CALLBACK_LOG) as records:
            travel.add()
        self.assertEqual(1, len(records), records)
        self.assertEqual("subscribe_callback", records[0].args[0])
        self.assertEqual("PlayerTravelled", records[0].args[1])

        evt_id = travel._BaseEvent__evt_id
        self.assertTrue(evt_id)
        self.assertIs(travel, mc.travel)

        with debug_records(mc_builtin.CALLBACK_LOG) as records:
            travel.remove()
        self.assertEqual(1, len(records), records)
        self.assertEqual("unsubscribe_callback", records[0].args[0])
        self.assertEqual(evt_id, records[0].args[1])

        self.assertIsNone(travel._BaseEvent__evt_id)
        self.assertIsNone(mc.travel._BaseEvent__evt_id)
