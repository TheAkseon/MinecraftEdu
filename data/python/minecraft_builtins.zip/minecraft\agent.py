"""The agent actor.

Because these commands are executed by a particular client,
the target agent is always the one owned by the caller.
"""

from __future__ import annotations

import contextlib
import logging
import json

from minecraft import enums
from minecraft._builtins import (
    execute_command,
    subscribe_callback,
    unsubscribe_callback,
    Lock,
    MinecraftError,
)
from minecraft.location import as_loc, LocationType

__all__ = ["Agent"]


LOG = logging.getLogger(__name__)


class Agent:
    def __init__(self):
        self._event = None
        self._command_response = None

    def _on_agent_command(self, response):
        try:
            result = json.loads(response["properties"]["Result"])
            self._command_response[result["commandName"]] = result
        except Exception as ex:
            LOG.error("Invalid response from agent command", exc_info=True)
            self._command_response["except"] = str(ex)
        finally:
            self._event.release()

    # Refactored out for easy patching in tests
    def _agent_command_wait(self, evt):
        if not evt.acquire(5):
            raise MinecraftError("Failed to get response")

    @contextlib.contextmanager
    def _agent_command(self, command, *args):
        evt = self._event
        if evt:
            evt.acquire()
        else:
            self._event = evt = Lock(True)
            self._command_response = {}
        evt_id = subscribe_callback(
            enums.Event.AGENTCOMMAND, self._on_agent_command, on_main_thread=False
        )
        try:
            execute_command("agent", command, *args).wait()
            self._agent_command_wait(evt)
            data = self._command_response.pop(command, None)
            exception = self._command_response.pop("except", None)
            evt.release()
            if exception:
                raise exception
        finally:
            unsubscribe_callback(evt_id)
        yield data

    @property
    def position(self) -> LocationType:
        """Gets the current position of the agent.
        """
        resp = execute_command("agent getposition").result()
        pos = resp["body"]["position"]
        return as_loc(float(pos["x"]), float(pos["y"]), float(pos["z"]))

    @position.setter
    def position(self, value: LocationType):
        """Moves the Agent to the given location.
        """
        self.teleport(value)

    def teleport(self, location: LocationType = None, facing: LocationType = None):
        """Teleports the Agent to the player or a given location.
        """
        if location:
            if facing:
                execute_command("tp", "@c", as_loc(location), "facing", as_loc(facing)).wait(delay=0.5)
            else:
                execute_command("tp", "@c", as_loc(location)).wait(delay=0.5)
        else:
            execute_command("agent tp").wait(delay=0.5)

    @property
    def rotation(self) -> float:
        """Gets the current rotation of the agent in degrees.
        """
        resp = execute_command("agent getposition").result()
        return float(resp["body"]["y-rot"])

    def inspect(self, direction: enums.Direction):
        """Get the name of the block in the specified direction.
        """
        with self._agent_command(
            "inspect", enums.Direction.name_to_name(direction)
        ) as data:
            return data.get("blockName", "")

    def _inspect_data(self, direction: enums.Direction):
        """[DEPRECATED] Get the data value of the block in the specified
        direction.
        """
        with self._agent_command(
            "inspectdata", enums.Direction.name_to_name(direction)
        ) as data:
            return data

    def inspect_data(self, direction: enums.Direction):
        """[DEPRECATED] Get the data value of the block in the specified
        direction.
        """
        with self._agent_command(
            "inspectdata", enums.Direction.name_to_name(direction)
        ) as data:
            return data

    def move(self, direction: enums.Direction):
        """Attempts to move Agent in specified direction.

        Returns True if Agent moved; False if it was blocked.
        """
        with self._agent_command("move", enums.Direction.name_to_name(direction)):
            return

    def turn(self, direction: enums.TurnDirection):
        """Attempts to rotate Agent 90 degrees left or right.
        """
        with self._agent_command("turn", enums.TurnDirection.name_to_name(direction)):
            return

    def give(self, item: enums.Giveable, quantity: int, slot_number: int):
        """Sets an inventory item.

        Item is the name of the item.
        Quantity is the number of items to give the agent.
        Slot number is the inventory slot (1-27).

        To give a block with a non-zero data value, pass a
        tuple with (name, data_value, components).
        """
        item_name, item_data, item_components = enums.Giveable.name_to_name_data_components(
            item
        )

        execute_command(
            "agent setitem",
            slot_number,
            item_name,
            quantity,
            item_data,
            item_components,
        ).wait()

    def get_item(self, slot_number: int):
        """Gets the name of the item in the inventory slot.

        Slot number is the inventory slot (1-27).
        """
        with self._agent_command("getitemdetail", slot_number) as data:
            return enums.Block.name_to_nice_name(data.get("itemName", ""))

    def get_item_count(self, slot_number: int):
        """Gets the name of the item in the inventory slot.

        Slot number is the inventory slot (1-27).
        """
        with self._agent_command("getitemcount", slot_number) as data:
            return int(data.get("stackCount", 0))

    def transfer(self, slot_number: int, quantity: int, dest_slot_number: int):
        """Transfers items from one inventory slot to another.

        Slot number and dest slot number are the inventory slots (1-27).
        Quantity is the number of items.
        """
        with self._agent_command("transfer", slot_number, quantity, dest_slot_number):
            return

    def place(self, slot_number: int, direction: enums.Direction):
        """Places a block or uses an inventory item.

        Slot number is the inventory slot (1-27).
        Direction is the direction relative to the agent to
        place or use the item.
        """
        with self._agent_command("place", slot_number, enums.Direction.name_to_name(direction)):
            return

    def drop(
        self,
        slot_number: int,
        quantity: int = 64,
        direction: enums.Direction = "forward",
    ):
        """Drops a number of items from an inventory slot.

        Slot number is the inventory slot (1-27).
        Quantity is the number of items to drop.
        Direction is the direction relative to the agent to drop.
        """
        with self._agent_command("drop", slot_number, quantity, enums.Direction.name_to_name(direction)):
            return

    def attack(self, direction: enums.Direction):
        """Attacks in the specified direction.
        """
        with self._agent_command("attack", enums.Direction.name_to_name(direction)):
            return

    def destroy(self, direction: enums.Direction):
        """Destroys a breakable block or item.
        """
        with self._agent_command("destroy", enums.Direction.name_to_name(direction)):
            return

    def collect(self, item: enums.Giveable = None):
        """Collects all items of the specified type.
        """
        if not item:
            with self._agent_command("collect all"):
                return
        
        with self._agent_command("collect", enums.Giveable.name_to_name_only(item)):
            return

    def till(self, direction: enums.Direction):
        """Tills the soil by hoe in the specified direction.
        """
        with self._agent_command("till", enums.Direction.name_to_name(direction)):
            return

    def say(self, *message):
        """Make your agent say something.

        If you pass multiple things, they will be joined with spaces.
        """
        if not message:
            return

        execute_command(
            "execute", "@c", "~ ~ ~", "say", " ".join(map(str, message))
        ).wait()
