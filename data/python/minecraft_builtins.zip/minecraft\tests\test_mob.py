import unittest

from .support import command_result, debug_records

import minecraft._builtins as mc_builtin
import minecraft.enums as mc_enums
import minecraft.event as mc_event

from minecraft.mob import Mob


class TestMob(unittest.TestCase):
    def test_find(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Mob.find("zombie", count=3, radius=1, position="~ ~ ~")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("tag", records[0].args[1])
        self.assertEqual(
            "@e[c=3,r=1,x=~0.0,y=~0.0,z=~0.0,type=zombie]", records[0].args[2][0]
        )
        self.assertEqual("wait", records[1].args[0])

    def test_kill(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Mob("A").kill()
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("kill", records[0].args[1])
        self.assertEqual('@e[tag="A"]', records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_teleport(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Mob("A").teleport("10 ~5 -5")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("teleport", records[0].args[1])
        self.assertEqual('@e[tag="A"]', records[0].args[2][0])
        self.assertEqual((10, "~5", -5), records[0].args[2][1:4])
        self.assertEqual("wait", records[1].args[0])

    def test_give(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Mob("A").give("diamond sword")
            Mob("A").give("diamond helmet", "head")
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("replaceitem", records[0].args[1])
        self.assertEqual(
            ("entity", '@e[tag="A"]', "slot.weapon.mainhand", 0, "diamond_sword", 1),
            records[0].args[2],
        )
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("replaceitem", records[2].args[1])
        self.assertEqual(
            ("entity", '@e[tag="A"]', "slot.armor.head", 0, "diamond_helmet", 1),
            records[2].args[2],
        )
        self.assertEqual("wait", records[3].args[0])
