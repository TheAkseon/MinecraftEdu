import unittest

from .support import command_result, debug_records

import minecraft._builtins as mc_builtin
import minecraft.event as mc_event

from minecraft.agent import Agent


class TestAgent(unittest.TestCase):
    def test_teleport(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().teleport()
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent tp", records[0].args[1])
        self.assertEqual("wait", records[1].args[0])

    def test_get_position(self):
        with command_result(
            "agent getposition", {"position": {"x": 0, "y": 0, "z": 0}}
        ):
            with debug_records(mc_builtin.COMMAND_LOG) as records:
                Agent().position
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent getposition", records[0].args[1])
        self.assertEqual("result", records[1].args[0])

    def test_set_position(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().position = 0, 0, 0
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("tp", records[0].args[1])
        self.assertEqual("@c", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_get_rotation(self):
        with command_result("agent getposition", {"y-rot": 90}):
            with debug_records(mc_builtin.COMMAND_LOG) as records:
                Agent().rotation
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent getposition", records[0].args[1])
        self.assertEqual("result", records[1].args[0])

    def test_inspect(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            agent = Agent()

            def on_wait(*a):
                agent._command_response["inspect"] = {"blockName": "air"}

            agent._agent_command_wait = on_wait
            r = agent.inspect("FORWARD")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent", records[0].args[1])
        self.assertEqual("inspect", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("air", r)

    def test_move(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().move("FORWARD")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent move", records[0].args[1])
        self.assertEqual("forward", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_turn(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().turn("LEFT")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent turn", records[0].args[1])
        self.assertEqual("left", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_turn_directions_only(self):
        with self.assertRaises(mc_builtin.MinecraftError):
            Agent().turn("FORWARD")

    def test_give(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().give("STONE", 64, 1)
            Agent().give(("BRICK BLOCK", 5), 64, 1)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent setitem", records[0].args[1])
        self.assertEqual((1, "stone", 64, 0, ""), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("agent setitem", records[2].args[1])
        self.assertEqual((1, "brick_block", 64, 5, ""), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_transfer(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().transfer(1, 2, 3)
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent transfer", records[0].args[1])
        self.assertEqual(1, records[0].args[2][0])
        self.assertEqual(2, records[0].args[2][1])
        self.assertEqual(3, records[0].args[2][2])
        self.assertEqual("wait", records[1].args[0])

    def test_place(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().place(1, "BACK")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent place", records[0].args[1])
        self.assertEqual((1, "back"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_drop(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().drop(1, 2, "LEFT")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent drop", records[0].args[1])
        self.assertEqual((1, 2, "left"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_attack(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().attack("LEFT")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent attack", records[0].args[1])
        self.assertEqual("left", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_destroy(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().destroy("RIGHT")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent destroy", records[0].args[1])
        self.assertEqual("right", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_collect(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().collect("STONE")
            Agent().collect()
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent collect", records[0].args[1])
        self.assertEqual("stone", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("agent collect all", records[2].args[1])
        self.assertEqual("wait", records[3].args[0])

    def test_till(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().till("RIGHT")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("agent till", records[0].args[1])
        self.assertEqual("right", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_say(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Agent().say("hello", "world")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("execute", records[0].args[1])
        self.assertEqual(("@c", "~ ~ ~", "say", "hello world"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
