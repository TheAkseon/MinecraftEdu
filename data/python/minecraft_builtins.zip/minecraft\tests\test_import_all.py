import unittest


class TestImportAll(unittest.TestCase):
    def test_import_all(self):
        import minecraft._builtins
        import minecraft.agent
        import minecraft.enums
        import minecraft.event
        import minecraft.location
        import minecraft.player
        import minecraft.world

    def test_import_builtins(self):
        try:
            import _minecraft_builtins
        except ModuleNotFoundError as ex:
            self.skipTest("ModuleNotFoundError occurred")
        except ImportError as ex:
            if ex.name != "_minecraft_builtins":
                raise
            if "Not running" not in str(ex):
                raise

    def test_import_easy(self):
        try:
            import _minecraft_easy
        except ModuleNotFoundError as ex:
            if ex.name != "_minecraft_easy":
                raise
            self.skipTest("ModuleNotFoundError occurred")
