import unittest

from .support import command_result, debug_records

import minecraft._builtins as mc_builtin
import minecraft.enums as mc_enums
import minecraft.event as mc_event

from minecraft.world import World


class TestWorld(unittest.TestCase):
    def test_summon(self):
        with command_result("summon", {}):
            with debug_records(mc_builtin.COMMAND_LOG) as records:
                World().summon("PIG")
                World().summon("Moo Shroom", (1, 2, 3))
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("summon", records[0].args[1])
        self.assertEqual(("pig", "^ ^1 ^3"), records[0].args[2])
        self.assertEqual("result", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("summon", records[2].args[1])
        self.assertEqual(("mooshroom", "1 2 3"), records[2].args[2])
        self.assertEqual("result", records[3].args[0])

    def test_spawn_mob(self):
        with command_result("summon", {}):
            with debug_records(mc_builtin.COMMAND_LOG) as records:
                World().spawn("PIG", None, 2)
                World().spawn("Moo Shroom", (1, 2, 3), 1)
        self.assertEqual(6, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("execute_command", records[1].args[0])
        self.assertEqual("summon", records[0].args[1])
        self.assertEqual("summon", records[1].args[1])
        self.assertEqual(("pig", "^ ^1 ^3"), records[0].args[2])
        self.assertEqual(("pig", "^ ^1 ^3"), records[1].args[2])
        self.assertEqual("result", records[2].args[0])
        self.assertEqual("result", records[3].args[0])

        self.assertEqual("execute_command", records[4].args[0])
        self.assertEqual("summon", records[4].args[1])
        self.assertEqual(("mooshroom", "1 2 3"), records[4].args[2])
        self.assertEqual("result", records[5].args[0])

    def test_spawn_item(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().spawn("Diamond Sword")
            World().spawn("Gold NUGGET", (1, 2, 3), 64)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("spawnitem", records[0].args[1])
        self.assertEqual(("diamond_sword", "^ ^2 ^1", 1), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("spawnitem", records[2].args[1])
        self.assertEqual(("gold_nugget", "1 2 3", 64), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_spawn_block(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().spawn("Diamond Ore")
            World().spawn("STONE", (1, 2, 3), 64)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("spawnitem", records[0].args[1])
        self.assertEqual(("diamond_ore", "^ ^2 ^1", 1), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("spawnitem", records[2].args[1])
        self.assertEqual(("stone", "1 2 3", 64), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_spawn_invalid(self):
        with self.assertRaises(mc_enums.UnknownEnumValueError):
            World().spawn("made up name")

    def test_gamerule_getset(self):
        with command_result("gamerule", {"details": '{"dodaylightcycle": true}'}):
            with debug_records(mc_builtin.COMMAND_LOG) as records:
                self.assertIs(True, World().gamerule["Do Daylight Cycle"])
                World().gamerule["Do Daylight Cycle"] = False

        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("gamerule", records[0].args[1])
        self.assertEqual("dodaylightcycle", records[0].args[2][0])
        self.assertEqual("result", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("gamerule", records[2].args[1])
        self.assertEqual(("dodaylightcycle", False), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_gamerule_iterate(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            keys = list(World().gamerule)
            with command_result(
                "gamerule",
                {"details": "{" + ",".join(f'"{k}": true' for k in keys) + "}"},
            ):
                items = list(World().gamerule.items())

        self.assertTrue(keys)
        self.assertTrue(items)
        self.assertSetEqual(set(keys), set(k for k, v in items))
        self.assertSetEqual({True}, set(v for k, v in items))
        for i, k in enumerate(keys):
            args = records[i * 2].args
            self.assertEqual("execute_command", args[0])
            self.assertEqual("gamerule", args[1])
            self.assertEqual(k, args[2][0])
            args = records[i * 2 + 1].args
            self.assertEqual("result", args[0])

    def test_title(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().show_title("Title", "Subtitle", "Action Bar", 1, 2, 3)
            World().clear_title()
        self.assertEqual(12, len(records), records)
        self.assertEqual(("execute_command", "title"), records[0].args[0:2])
        self.assertEqual(("execute_command", "title"), records[1].args[0:2])
        self.assertEqual(("execute_command", "title"), records[2].args[0:2])
        self.assertEqual(("execute_command", "title"), records[3].args[0:2])
        self.assertEqual(("execute_command", "title"), records[4].args[0:2])
        self.assertEqual(("@a", "reset"), records[0].args[2])
        self.assertEqual(("@a", "times", 1, 2, 3), records[1].args[2])
        self.assertEqual(("@a", "title", "Title"), records[2].args[2])
        self.assertEqual(("@a", "subtitle", "Subtitle"), records[3].args[2])
        self.assertEqual(("@a", "actionbar", "Action Bar"), records[4].args[2])
        self.assertEqual("wait", records[5].args[0])
        self.assertEqual("wait", records[6].args[0])
        self.assertEqual("wait", records[7].args[0])
        self.assertEqual("wait", records[8].args[0])
        self.assertEqual("wait", records[9].args[0])
        self.assertEqual(("execute_command", "title"), records[10].args[0:2])
        self.assertEqual(("@a", "clear"), records[10].args[2])
        self.assertEqual("wait", records[11].args[0])

    def test_put_in(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().put_in((0, 0, 0), "DIAMOND PICK AXE", 1, 5)
            World().put_in((0, 0, 0), "DIAMOND PICK AXE", 1, 12)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("replaceitem", records[0].args[1])
        self.assertEqual(
            ("block", "0 0 0", "slot.container", 5, "diamond_pickaxe", 1, 0, ""),
            records[0].args[2],
        )
        self.assertEqual("wait", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("replaceitem", records[2].args[1])
        self.assertEqual(
            ("block", "0 0 0", "slot.container", 12, "diamond_pickaxe", 1, 0, ""),
            records[2].args[2],
        )
        self.assertEqual("wait", records[3].args[0])

    def test_set(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().set((0, 0, 0), "STONE")
            World().set((0, 0, 0), ("STONE", 3), "destroy")
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("setblock", records[0].args[1])
        self.assertEqual(("0 0 0", "stone", 0, "replace"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("setblock", records[2].args[1])
        self.assertEqual(("0 0 0", "stone", 3, "destroy"), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_clone(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().clone(
                (0, 0, 0), (5, 5, 5), (10, 10, 10), filter_block="NOT A REAL BLOCK"
            )
            World().clone(
                (0, 0, 0), (5, 5, 5), (10, 10, 10), "FILTERED", "MOVE", "STONE"
            )
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("clone", records[0].args[1])
        self.assertEqual(
            ("0 0 0", "5 5 5", "10 10 10", "replace", "normal"), records[0].args[2]
        )
        self.assertEqual("result", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("clone", records[2].args[1])
        self.assertEqual(
            ("0 0 0", "5 5 5", "10 10 10", "filtered", "move", "stone", 0),
            records[2].args[2],
        )
        self.assertEqual("result", records[3].args[0])

    def test_fill(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            World().fill("0 0 0", "10 10 10", ("DIAMOND ORE", 3), "DE-STROY!")
            World().fill("0 0 0", "10 10 10", "STONE", "REPLACE", "WATER")
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("fill", records[0].args[1])
        self.assertEqual(
            ("0 0 0", "10 10 10", "diamond_ore", 3, "destroy"), records[0].args[2]
        )
        self.assertEqual("result", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("fill", records[2].args[1])
        self.assertEqual(
            ("0 0 0", "10 10 10", "stone", 0, "replace", "water", 0), records[2].args[2]
        )
        self.assertEqual("result", records[3].args[0])
