from __future__ import annotations

import minecraft._builtins as _mc_builtin
import re
import typing


class InvalidLocationError(_mc_builtin.MinecraftError):
    _DEFAULT_MESSAGE = "location should be 'x y z' or (x, y, z)"

    def __init__(self, message=None):
        super().__init__(message or InvalidLocationError._DEFAULT_MESSAGE)


class Location:
    @classmethod
    def _to_pos_rel(cls, v):
        if v is None:
            raise InvalidLocationError()
        if isinstance(v, tuple) and len(v) == 2:
            return v
        try:
            if isinstance(v, str) and v.startswith(("~", "^")):
                return float(v[1:] or "0"), v[0]
            return float(v), None
        except (TypeError, ValueError) as ex:
            raise InvalidLocationError()

    def __init__(self, x, y, z):
        self.x, self.x_rel = self._to_pos_rel(x)
        self.y, self.y_rel = self._to_pos_rel(y)
        self.z, self.z_rel = self._to_pos_rel(z)

    @classmethod
    def parse(cls, value, *args) -> Location:
        if args:
            if len(args) == 2:
                return cls(value, *args)
        elif isinstance(value, cls):
            return value
        elif isinstance(value, str):
            parts = re.split("\\s+", value, maxsplit=4)
            if len(parts) == 3:
                return cls(*parts)
        elif hasattr(value, "__iter__"):
            parts = []
            for v in value:
                parts.append(v)
                if len(parts) > 3:
                    break
            if len(parts) == 3:
                return cls(*parts)
        raise InvalidLocationError()

    def __add__(self, other: LocationType):
        if not isinstance(other, Location):
            try:
                other = self.parse(other)
            except (TypeError, ValueError, InvalidLocationError):
                return NotImplemented
        return type(self)(
            *(
                (sp + op, sr)
                for sp, sr, op in zip(self.values(), self._rels(), other.values())
            )
        )

    def __sub__(self, other: Location):
        if not isinstance(other, Location):
            try:
                other = self.parse(other)
            except (TypeError, ValueError, InvalidLocationError):
                return NotImplemented
        return type(self)(
            *(
                (sp - op, sr)
                for sp, sr, op in zip(self.values(), self._rels(), other.values())
            )
        )

    def __mul__(self, other: float):
        try:
            factor = float(other)
        except (TypeError, OverflowError, ValueError):
            return NotImplemented
        return type(self)(
            *((sp * factor, sr) for sp, sr in zip(self.values(), self._rels()))
        )

    def __truediv__(self, other: float):
        try:
            factor = float(other)
        except (TypeError, OverflowError, ValueError):
            return NotImplemented
        return type(self)(
            *((sp / factor, sr) for sp, sr in zip(self.values(), self._rels()))
        )

    def __floordiv__(self, other: float):
        try:
            factor = float(other)
        except (TypeError, OverflowError, ValueError):
            return NotImplemented
        return type(self)(
            *((sp // factor, sr) for sp, sr in zip(self.values(), self._rels()))
        )

    def __eq__(self, other):
        if not isinstance(other, Location):
            try:
                other = self.parse(other)
            except (TypeError, ValueError, InvalidLocationError):
                return NotImplemented
        return all(s == o for s, o in zip(self, other))

    def __ne__(self, other):
        if not isinstance(other, Location):
            try:
                other = self.parse(other)
            except (TypeError, ValueError, InvalidLocationError):
                return NotImplemented
        return any(s != o for s, o in zip(self, other))

    def __len__(self):
        return 3

    def values(self):
        yield self.x
        yield self.y
        yield self.z

    def _rels(self):
        yield self.x_rel
        yield self.y_rel
        yield self.z_rel

    def _str(self, f):
        if isinstance(f, str):
            return f
        s = "{:.6f}".format(float(f)).rstrip("0")
        if not s:
            return "0"
        if s[-1] == ".":
            s = s[:-1]
        return s

    def __iter__(self):
        return iter(
            "{}{}".format(r, self._str(p)) if r and p else r if r else p
            for r, p in zip(self._rels(), self.values())
        )

    def __str__(self):
        return " ".join(self._str(p) for p in self)

    def __repr__(self):
        return "<{!s}:{!s}>".format(type(self).__name__, self)


LocationType = typing.Union[Location, typing.Tuple[float, float, float], str]


as_loc = Location.parse


def from_me(loc: LocationType, y: float = None, z: float = None):
    if not isinstance(loc, Location):
        loc = Location(loc, y, z)
    return type(loc)(*((i, "~") for i in loc))
