"""
"""
from __future__ import annotations

import json as _json
import logging as _logging
import threading as _threading
import typing as _typing
import uuid as _uuid

from importlib.resources import read_text as _import_text

try:
    from _minecraft_builtins import *
except ImportError:
    LOG = _logging.getLogger("minecraft")
    LOG.setLevel("DEBUG")
    COMMAND_LOG = _logging.getLogger("minecraft.commands")
    COMMAND_LOG.setLevel("DEBUG")
    CALLBACK_LOG = _logging.getLogger("minecraft.callbacks")
    CALLBACK_LOG.setLevel("DEBUG")

    _VANILLA_DATA = _json.loads(_import_text("minecraft", "vanilla.json"))

    class MinecraftError(RuntimeError):
        def __init__(self, message, code=None):
            if code:
                if code < 0:
                    code = 0x80000000 | (code & 0x7FFFFFFF)
                super().__init__("{} (Code: 0x{:08X})".format(message, code))
                self.code = code
            else:
                super().__init__(message)
                self.code = None

    class Lock:
        def __init__(self, already_locked=False):
            lock = _threading.Lock()
            if already_locked:
                lock.acquire()
            self._lock = lock

        def acquire(self, timeout=-1):
            raise RuntimeError("locks are not supported in mock Minecraft")

        def release(self):
            pass

    def get_block_names():
        return iter(_VANILLA_DATA["blocks"].values())

    def get_block_name(index):
        return _VANILLA_DATA["blocks"][str(index)].partition(";")[0]

    def get_item_names():
        return iter(_VANILLA_DATA["items"].values())

    def get_item_name(index):
        if index < 0:
            return get_block_name(255 - index)
        elif index < 256:
            return get_block_name(index)
        return _VANILLA_DATA["items"][str(index)].partition(";")[0]

    def get_mob_names():
        return iter(_VANILLA_DATA["mobs"].values())

    def get_mob_name(index):
        return _VANILLA_DATA["mobs"][str(index)].partition(";")[0]

    COMMAND_HANDLERS: _typing.Dict[str, _typing.Any] = {}

    class _CommandResult:
        def __init__(self, command, result):
            self.request_id = _uuid.uuid4().hex
            self._command = command
            self._error = None
            self._result = {}
            if isinstance(result, Exception):
                self._error = result
            elif result is not None:
                self._result = result

        def result(self, timeout: float = 5.0, delay: float = 0.1) -> dict:
            COMMAND_LOG.debug(
                "%s(%r, %0.3f, %0.3f) -> %r raise %r",
                "result",
                self.request_id,
                timeout,
                delay,
                self._result,
                self._error,
            )
            if self._error:
                raise self._error
            return self._result

        def wait(self, timeout: float = 5.0, delay: float = 0.1):
            COMMAND_LOG.debug(
                "%s(%r, %0.3f, %0.3f) raise %r",
                "wait",
                self.request_id,
                timeout,
                delay,
                self._error,
            )
            if self._error:
                raise self._error

    def execute_command(command: str, *args):
        COMMAND_LOG.debug("%s(%r, %r)", "execute_command", command, args)
        handler = COMMAND_HANDLERS.get(command)
        result = None
        if handler:
            try:
                result = handler(*args)
            except Exception as ex:
                result = ex
        return _CommandResult(command, result)

    def subscribe_callback(
        event_name: str, callback: _typing.Callable, *, on_main_thread: bool = True
    ) -> str:
        evt_id = _uuid.uuid4().hex
        CALLBACK_LOG.debug(
            "%s(%r, %r, %r) -> %r",
            "subscribe_callback",
            event_name,
            callback,
            on_main_thread,
            evt_id,
        )
        return evt_id

    def unsubscribe_callback(event_id: str):
        CALLBACK_LOG.debug("%s(%r)", "unsubscribe_callback", event_id)

    def clear_callbacks(event_name: str = None):
        CALLBACK_LOG.debug("%s(%r)", "clear_callbacks", event_name)

    def call_later(seconds: float, callback: _typing.Callable):
        CALLBACK_LOG.debug("%s(%0.3f, %r)", "call_later", seconds, callback)
