"""The world model.
"""

from __future__ import annotations

import json
import logging

from minecraft import enums
from minecraft._builtins import execute_command, MinecraftError
from minecraft.mob import Mob
from minecraft.player import Player
from minecraft.location import as_loc, LocationType

__all__ = ["World"]


LOG = logging.getLogger(__name__)


class GameRuleDict:
    def __getitem__(self, rulename):
        try:
            rulename = enums.GameRule.name_to_name(rulename)
        except MinecraftError:
            raise KeyError(rulename) from None

        # The rule status is returned as JSON text in the body.details field.
        resp = execute_command("gamerule", rulename).result()
        try:
            res = json.loads(resp["body"]["details"])
            return res[rulename]
        except Exception:
            raise MinecraftError(
                "Failed to get status of game rule '{}'".format(rulename)
            )

    def get(self, rulename, default=None):
        try:
            return self[rulename]
        except (LookupError, MinecraftError):
            return default

    def __setitem__(self, rulename, value):
        rulename = enums.GameRule.name_to_name(rulename)
        execute_command("gamerule", rulename, value).wait()

    def __iter__(self):
        return (getattr(enums.GameRule, n) for n in enums.GameRule._names)

    def keys(self):
        return iter(self)

    def values(self):
        return (self[k] for k in iter(self))

    def items(self):
        return ((k, self[k]) for k in iter(self))


class World:
    def __init__(self):
        self._all_players = Player(key="@a")
        self._gamerules = GameRuleDict()

    @property
    def gamerule(self):
        """A dict containing the current game rules.
        """
        return self._gamerules

    def players(self):
        """A list containing all players in the game.
        """
        players = execute_command("list").result()["body"]["players"]
        return [Player(name=n.strip()) for n in players.split(",")]

    def set_difficulty(self, difficulty: enums.Difficulty):
        """Sets the world's difficulty.
        """
        execute_command("difficulty", enums.Difficulty.name_to_name(difficulty)).wait()

    def play_sound(
        self,
        sound: str,
        location: LocationType = None,
        volume: float = 1.0,
        pitch: float = 1.0,
        minimum_volume: float = 0.0,
    ):
        """Plays the specified sound to at a location.
        """
        self._all_players.play_sound(sound, location, volume, pitch, minimum_volume)

    def show_title(
        self,
        title: str = None,
        subtitle: str = None,
        actionbar: str = None,
        fade_in: float = 10,
        stay: float = 70,
        fade_out: float = 20,
    ):
        """Displays the specified title to all players.
        """
        self._all_players.show_title(
            title, subtitle, actionbar, fade_in, stay, fade_out
        )

    def clear_title(self):
        """Clears the currently visible title.
        """
        self._all_players.clear_title()

    def summon(self, mob: enums.Mob, location: LocationType = None, amount: int = 1):
        """Spawns a mob at a given location.

        If no location is given, spawns on the player.
        """
        if location is None:
            location = "^ ^1 ^"
        mob = enums.Mob.name_to_name(mob)
        location = as_loc(location)
        tasks = [execute_command("summon", mob, location) for _ in range(amount)]
        r = [i.result() for i in tasks]
        if r:
            pos = r[0]["body"].get("spawnPos")
            if not pos:
                LOG.info("No position returned, so cannot tag mobs")
                return
            return Mob.find(mob, position=(pos["x"], pos["y"], pos["z"]), count=len(r))

    def spawn(
        self, item: enums.Giveable, location: LocationType = None, amount: int = 1
    ):
        """Spawns an item at a given location.

        If no location is given, spawns on the player.
        """
        if amount < 0:
            raise MinecraftError("Cannot spawn negative items")
        if amount == 0:
            return
        if amount > 64:
            LOG.warning("Spawning items is capped at 64")
            amount = 64

        item_key = None
        try:
            item_key = enums.Giveable.name_to_name(item)
        except MinecraftError:
            # Might have been a mob name
            try:
                mob_key = enums.Mob.name_to_name(item)
            except MinecraftError:
                pass
            else:
                # It was a mob! Let's summon it instead of spawnitem-ing it
                return self.summon(mob_key, location, amount)

        if item_key is None:
            # Neither a giveable nor a mob
            raise enums.UnknownEnumValueError(enums.Giveable, item)

        if location is None:
            location = "^ ^2 ^"

        execute_command("spawnitem", item_key, as_loc(location), amount).wait()

    def put_in(
        self, location: LocationType, item: enums.Giveable, count: int, slot_number: int
    ):
        """Put one or more items inside a container block.
        """
        item_name, item_data, item_components = enums.Giveable.name_to_name_data_components(
            item
        )

        execute_command(
            "replaceitem",
            "block",
            as_loc(location),
            "slot.container",
            slot_number,
            item_name,
            count,
            item_data,
            item_components,
        ).wait()

    def is_block(self, location: LocationType, block: enums.Block):
        """Tests whether a certain location contains a certain block.
        """
        t = execute_command(
            "testforblock", as_loc(location), *enums.Block.name_to_name_and_data(block)
        )
        try:
            return t.result()["body"]["matches"]
        except MinecraftError:
            return False

    def set(
        self,
        location: LocationType,
        block: enums.Block,
        mode: enums.BlockReplaceMode = "replace",
    ):
        """Sets a certain location to a block.

        Returns True if the block was set, or False if not.
        """
        mode = enums.BlockReplaceMode.name_to_name(mode)
        t = execute_command(
            "setblock",
            as_loc(location),
            *enums.Block.name_to_name_and_data(block),
            mode,
        )
        try:
            t.wait()
        except MinecraftError as ex:
            if ex.code == 0x80020000:
                # Failed to replace, probably because it's identical
                return False
            raise
        return True

    def clone(
        self,
        begin: LocationType,
        end: LocationType,
        destination: LocationType,
        mask_mode: enums.MaskMode = "replace",
        clone_mode: enums.CloneMode = "normal",
        filter_block: enums.Block = None,
    ):
        """Clones a set of blocks from begin-end to destination.

        Specify filter_block when using 'filtered' mask mode to only
        clone blocks of that type. Pass (name, data_value) to specify
        non-zero data value for the filter.
        """
        mask_mode = enums.MaskMode.name_to_name(mask_mode)
        clone_mode = enums.CloneMode.name_to_name(clone_mode)
        args = (
            "clone",
            as_loc(begin),
            as_loc(end),
            as_loc(destination),
            mask_mode,
            clone_mode,
        )
        if mask_mode == "filtered" and filter_block:
            args += enums.Block.name_to_name_and_data(filter_block)

        t = execute_command(*args)
        try:
            return t.result().get("body", {}).get("count", 0)
        except MinecraftError as ex:
            if ex.code == 0x80020000:
                # Failed to replace any blocks, probably because it's identical
                return 0
            raise

    def fill(
        self,
        begin: LocationType,
        end: LocationType,
        block: enums.Block,
        fill_mode: enums.FillMode = "replace",
        replace_block: enums.Block = None,
    ):
        """Fills a set of blocks from begin to end.

        Specify replace_block to only replace blocks matching that type.
        Pass a (name, data_value) tuple for non-zero data values.
        """
        block_name, block_data = enums.Block.name_to_name_and_data(block)
        fill_mode = enums.FillMode.name_to_name(fill_mode)
        args = ("fill", as_loc(begin), as_loc(end), block_name, block_data, fill_mode)
        if replace_block:
            args += enums.Block.name_to_name_and_data(replace_block)

        t = execute_command(*args)
        try:
            return t.result().get("body", {}).get("fillCount", 0)
        except MinecraftError as ex:
            if ex.code == 0x80020000:
                # Failed to replace any blocks, probably because they're identical
                return 0
            raise

    def set_weather(
        self,
        effect: enums.WeatherEffect,
        duration: int = 3000
    ):
        """Sets the specified weather to last for the specified duration. The duration is measured in 1/10th seconds.
        """
        execute_command(
            "weather",
            enums.WeatherEffect.name_to_name(effect),
            duration,
        ).wait()

    @property
    def weather(self) -> enums.WeatherEffect:
        """Gets the current weather of the world.
        """
        resp = execute_command("weather query").result()
        return enums.WeatherEffect.value_to_name(resp["body"]["data"])

    @weather.setter
    def weather(self, value: enums.WeatherEffect):
        """Sets the weather of the world.
        """
        self.set_weather(value)

    def get_time(
        self,
        queryType: enums.TimeQuery = "daytime"
    ):
        """Gets the specified time query type.
        """
        resp = execute_command("time query", enums.TimeQuery.name_to_name(queryType)).result()
        return resp["body"]["data"]

    @property
    def time(self) -> int:
        """Gets the current time of the world.
        """
        resp = execute_command("time query daytime").result()
        return resp["body"]["data"]

    @time.setter
    def time(self, value: int):
        """Sets the specified time via number or also the keywords
        """
        execute_command("time set", value).wait()
