"""The builtin objects used by the Minecraft Python framework.

This module is imported at initialization and is used to define the core
classes that will be used by the script runtime.

Everything here is considered internal implementation.
"""

from __future__ import annotations

import functools
import json
import logging
import os
import sys
import time
import threading
import traceback
import typing
import uuid

__all__ = [
    "Lock",
    "LOG",
    "MinecraftError",
    "get_block_names",
    "get_block_name",
    "get_item_names",
    "get_item_name",
    "get_mob_names",
    "get_mob_name",
    "execute_command",
    "subscribe_callback",
    "unsubscribe_callback",
    "clear_callbacks",
    "call_later",
]


# Replace time.sleep() with a version that is easier to cancel.
# Within this module we use _time_sleep() instead, but users who
# use time.sleep() will get better cancellation behavior.
_time_sleep = time.sleep


@functools.wraps(_time_sleep)
def sleep(seconds):
    stop_at = time.monotonic() + seconds

    # There is an issue with the python integration where sleep does not work correctly on windows
    # and may return immediately. Don't put a limit on the loop.
    while True:
        _time_sleep(0.01)
        if time.monotonic() > stop_at:
            break


time.sleep = sleep

_LANGUAGE_INTERFACE = None

should_shutdown = False


class MinecraftError(RuntimeError):
    def __init__(self, message, code=None):
        if code:
            if code < 0:
                code = 0x80000000 | (code & 0x7FFFFFFF)
            super().__init__("{} (Code: 0x{:08X})".format(message, code))
            self.code = code
        else:
            super().__init__(message)
            self.code = 0x80000000


class Lock:
    def __init__(self, already_locked=False):
        lock = threading.Lock()
        if already_locked:
            lock.acquire()
        self._lock = lock

    def acquire(self, timeout=-1):
        if timeout < 0:
            while True:
                if should_shutdown:
                    return False
                if self._lock.acquire(False):
                    return True
                _time_sleep(0.1)
            return False

        stop_at = time.monotonic() + timeout
        while time.monotonic() < stop_at:
            if should_shutdown:
                return False
            if self._lock.acquire(False):
                return True
            _time_sleep(0.1)
        return False

    def release(self):
        self._lock.release()


def _get_root_logger():
    log = logging.getLogger("minecraft")
    log.setLevel("WARNING")
    log.propagate = False
    if bool(os.getenv("MINECRAFT_PYTHON_TRACE")):
        log.setLevel("DEBUG")
        log.addHandler(logging.StreamHandler())
    return log


LOG = _get_root_logger()
COMMAND_LOG = logging.getLogger("minecraft.commands")
CALLBACK_LOG = logging.getLogger("minecraft.callbacks")


def _get_block_names(language_interface):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def _get_block_name(language_interface, index):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def _get_item_names(language_interface):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def _get_item_name(language_interface, index):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def _get_mob_names(language_interface):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def _get_mob_name(language_interface, index):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")


def get_block_names():
    return _get_block_names(_LANGUAGE_INTERFACE)


def get_block_name(index):
    return _get_block_name(_LANGUAGE_INTERFACE, index)


def get_item_names():
    return _get_item_names(_LANGUAGE_INTERFACE)


def get_item_name(index):
    return _get_item_name(_LANGUAGE_INTERFACE, index)


def get_mob_names():
    return _get_mob_names(_LANGUAGE_INTERFACE)


def get_mob_name(index):
    return _get_mob_name(_LANGUAGE_INTERFACE, index)


class CommandFuture:
    _PENDING: typing.Dict[str, CommandFuture] = {}

    def __init__(self, request_id, message):
        self.request_id = request_id
        self.message = message
        self._response = None
        self._lock = None
        self._PENDING[request_id] = self

    @classmethod
    def complete(cls, request_id, response):
        cls._PENDING.pop(request_id)._on_complete(response)

    def _on_complete(self, response):
        if self._response:
            raise RuntimeError("command was already complete")

        self._response = response

        if self._lock:
            self._lock.release()

    def _maybe_raise(self):
        try:
            code = self._response["body"]["statusCode"]
            message = self._response["body"].get("statusMessage", "Unknown error")
            if code >= 0:
                return
        except (TypeError, LookupError):
            return
        raise MinecraftError(message, code)

    def result(self, timeout: float = 1.0, delay: float = 0.1) -> dict:
        if not self._response:
            self.wait(timeout=timeout, delay=delay)

        try:
            self._maybe_raise()
        except Exception as ex:
            COMMAND_LOG.debug(
                "%s(%r, %0.3f, %0.3f) -> %r raise %r",
                "result",
                self.request_id,
                timeout,
                delay,
                self._response,
                ex,
            )
            raise

        COMMAND_LOG.debug(
            "%s(%r, %0.3f, %0.3f) -> %r",
            "result",
            self.request_id,
            timeout,
            delay,
            self._response,
        )
        return self._response

    def wait(self, timeout: float = 5.0, delay: float = 0.1):
        if self._response:
            self._maybe_raise()
            return

        if delay > 0:
            # Use the interruptible sleep here on purpose
            time.sleep(delay)

        if should_shutdown:
            raise TimeoutError("Shutdown")

        if not self._response:
            self._lock = lock = Lock(already_locked=True)
            if not self._response:
                lock.acquire(timeout)
                if not self._response:
                    raise TimeoutError("no response")

        try:
            self._maybe_raise()
        except Exception as ex:
            COMMAND_LOG.debug(
                "%s(%r, %0.3f, %0.3f) raise %r",
                "wait",
                self.request_id,
                timeout,
                delay,
                ex,
            )
            raise

        COMMAND_LOG.debug(
            "%s(%r, %0.3f, %0.3f) raise %r",
            "wait",
            self.request_id,
            timeout,
            delay,
            None,
        )


_SUBSCRIPTIONS: typing.Dict[str, typing.List[typing.Any]] = {}
_SUPPRESSED_EVENTS: typing.Set[str] = set()


def _send_message(language_interface, message):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")

# Logs to our debug console for release builds
def _log_to_console(message):
    # This will be replaced with a native function
    raise RuntimeError("commands not properly initialized")

def _queue_on_main_thread(language_interface, callback, args):
    # This will be replaced with a native function
    LOG.error("queue_on_main_thread function was not overridden")
    callback(*args)


def _call_subscriber(event_id, callback, *args):
    if event_id in _SUPPRESSED_EVENTS:
        CALLBACK_LOG.info("Event %s previously failed; skipping", event_id)
        return
    try:
        return callback(*args)
    except:
        if event_id:
            CALLBACK_LOG.error(
                "Unhandled error; suppressing %r (%s)",
                callback,
                event_id,
                exc_info=True,
            )
            # To prevent just this event from being raised again:
            #    _SUPPRESSED_EVENTS.add(event_id)

            # Since our eventual handler will tell the UI that we have
            # completed execution, it's better to cancel all callbacks.
            clear_callbacks()
        raise


def _on_response(response_str):
    # This will be called from native code on a worker thread
    response = json.loads(response_str)
    header = response["header"]
    body = response["body"]

    if header.get("messagePurpose") == "event":
        event_name = body.get("eventName")
        CALLBACK_LOG.info("Event '%s' raised", event_name)
        subs = list(_SUBSCRIPTIONS.get(event_name) or [])
        for evt_id, sub in subs:
            if evt_id.startswith("um:"):
                CALLBACK_LOG.info("Calling %r (%s) on callback thread", sub, evt_id)
                _call_subscriber(evt_id, sub, body)
            else:
                CALLBACK_LOG.info("Calling %r (%s) on main thread", sub, evt_id)
                _queue_on_main_thread(
                    _LANGUAGE_INTERFACE, _call_subscriber, (evt_id, sub, body)
                )
    elif header.get("messagePurpose") == "commandResponse":
        req_id = header.get("requestId")
        if req_id:
            COMMAND_LOG.info("Completing request %s on callback thread", req_id)
            CommandFuture.complete(req_id, response)
    else:
        LOG.warning("Unexpected response: %s", response_str)


def execute_command(command: str, *args) -> CommandFuture:
    if not isinstance(command, str):
        raise TypeError("expected 'str' for command")

    if args:
        command += " " + " ".join(str(a) for a in args if a is not None)

    COMMAND_LOG.info("Executing command %r", command)

    req_id = uuid.uuid4().hex
    message = {
        "header": {
            "messagePurpose": "commandRequest",
            "messageType": "commandRequest",
            "requestId": req_id,
            "version": 1,
        },
        "body": {"commandLine": command, "version": 1},
    }

    COMMAND_LOG.debug("%s(%r, %r) -> %r", "execute_command", command, args, req_id)

    cmd = CommandFuture(req_id, message)
    _send_message(_LANGUAGE_INTERFACE, json.dumps(message))
    return cmd


def subscribe_callback(event_name: str, callback, *, on_main_thread=True) -> str:
    if not isinstance(event_name, str):
        raise TypeError("expected 'str' for event_name")

    CALLBACK_LOG.info("Subscribing to event %r", event_name)

    evt_id = uuid.uuid4().hex
    if not on_main_thread:
        evt_id = "um:" + evt_id
    message = {
        "header": {
            "messagePurpose": "subscribe",
            "messageType": "commandRequest",
            "requestId": evt_id,
            "version": 1,
        },
        "body": {"eventName": event_name, "version": 1},
    }

    CALLBACK_LOG.debug(
        "subscribe_callback(%r, %r, %r) -> %r",
        event_name,
        callback,
        on_main_thread,
        evt_id,
    )

    _send_message(_LANGUAGE_INTERFACE, json.dumps(message))
    _SUBSCRIPTIONS.setdefault(event_name, []).append((evt_id, callback))
    return evt_id


def unsubscribe_callback(event_id: str):
    if not isinstance(event_id, str):
        raise TypeError("expected 'str' for event_id")

    CALLBACK_LOG.info("Unsubscribing callback %r", event_id)
    CALLBACK_LOG.debug("unsubscribe_callback(%r)", event_id)

    _SUPPRESSED_EVENTS.discard(event_id)

    for event_name, subs in list(_SUBSCRIPTIONS.items()):
        # Deplayed callbacks don't have subs attached to them. Ignore them.
        if not event_name.startswith("delayed:"):
            subs[:] = [s for s in subs if s[0] != event_id]

            if not subs:
                clear_callbacks(event_name)


def clear_callbacks(event_name=None):
    if event_name:
        clear_events = [event_name]
    else:
        _SUPPRESSED_EVENTS.clear()
        clear_events = list(_SUBSCRIPTIONS)

    for name in clear_events:
        if _SUBSCRIPTIONS.pop(name, None) is not None:
            CALLBACK_LOG.info("Unsubscribing from event %r", name)
            CALLBACK_LOG.debug("clear_callbacks(%r)", name)

            message = {
                "header": {
                    "messagePurpose": "unsubscribe",
                    "messageType": "commandRequest",
                    "requestId": uuid.uuid4().hex,
                    "version": 1,
                },
                "body": {"eventName": name, "version": 1},
            }

            _send_message(_LANGUAGE_INTERFACE, json.dumps(message))


class _DelayedCallback:
    def __init__(self, due_time, callback):
        self.due_time = due_time
        self._func = callback
        self.stopped = False
        # Stash a unique value in _SUBSCRIPTIONS so we count as an
        # event handler, but make it "None" so it doesn't do anything
        self._key = "delayed:{:016X}".format(id(self))
        _SUBSCRIPTIONS[self._key] = None

    def __call__(self, *args, **kwargs):
        if self.stopped:
            _SUBSCRIPTIONS.pop(self._key, None)
            return
        elif self._key not in _SUBSCRIPTIONS:
            return
        if time.monotonic() < self.due_time:
            _queue_on_main_thread(_LANGUAGE_INTERFACE, self, ())
        else:
            return self._func(*args, **kwargs)


def call_later(seconds: float, callback):
    if should_shutdown:
        raise TimeoutError("Shutdown")

    CALLBACK_LOG.debug("%s(%0.3f, %r)", "call_later", seconds, callback)
    CALLBACK_LOG.info("Calling %r in %0.3f seconds", callback, seconds)

    if seconds > 1:
        CALLBACK_LOG.warning("call_later is very inefficient for long delays!")

    # TODO: This could be improved to be less wasteful
    cb = _DelayedCallback(time.monotonic() + seconds, callback)
    _queue_on_main_thread(_LANGUAGE_INTERFACE, cb, ())


def _cancel_execution():
    clear_callbacks()
    should_shutdown = True
    raise RuntimeError("Cancelling execution")
