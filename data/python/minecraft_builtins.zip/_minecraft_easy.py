import minecraft._easy as mc_easy

get_easy_api = mc_easy.get_easy_api
