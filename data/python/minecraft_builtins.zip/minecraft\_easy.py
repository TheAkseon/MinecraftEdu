import logging as _logging

import minecraft._builtins as mc_builtin
import minecraft.agent as mc_agent
import minecraft.enums as mc_enum
import minecraft.event as mc_event
import minecraft.location as mc_loc
import minecraft.mob as mc_mob
import minecraft.player as mc_player
import minecraft.world as mc_world


__all__ = ["get_easy_api"]


LOG = _logging.getLogger("minecraft.easy")

def once(function):
    """Call the function once after all code has been compiled.
    """
    mc_builtin.call_later(0.1, function)
    function._minecraft_easy_once = True
    return function


class EasyAPIDict(dict):
    """Dictionary wrapper for some special global behaviors.

    When used as globals(), this dict will:
    * warn if one of the original settings is overridden
    * automatically subscribe events
    """

    def __init__(self, iterable):
        super().__init__(iterable)
        self._initial_keys = frozenset(self)

    def __setitem__(self, key, value):
        if key in self._initial_keys:
            LOG.warning("Careful! You just overwrote the '%s' value", key)

        # Associate event handlers immediately
        if isinstance(value, mc_event.forever):
            LOG.info("Activating forever function '%s'", value)
        elif getattr(value, "_minecraft_easy_once", False):
            LOG.info("Activating once function '%s'", value)
        elif key.startswith("on") and hasattr(value, "__call__"):
            LOG.info("Adding '%s' listener", key)
            evt = self["add_listener"](key, value)
            if evt:
                value = evt
            else:
                LOG.warning("Careful! '%s' is not an event name", key)

        super().__setitem__(key, value)


def get_easy_api():
    mc_builtin.clear_callbacks()

    _agent = mc_agent.Agent()
    _player = mc_player.Player()
    _world = mc_world.World()

    return EasyAPIDict(
        {
            # Require __builtins__ for normal operation
            "__builtins__": __builtins__,
            # Provide singleton objects
            "agent": _agent,
            "world": _world,
            "user": _player,
            "player": _player,
            # Provide common world and self commands
            "say": _player.say,
            "give": _player.give,
            "clear_inventory": _player.clear_inventory,
            "spawn": _world.spawn,
            "summon": _world.summon,
            "play_sound": _world.play_sound,
            "show_title": _world.show_title,
            # Relative location helper
            "from_me": mc_loc.from_me,
            # Internal helpers
            "forever": mc_event.forever,
            "once": once,
            "add_listener": mc_event.add_listener,
            "on_event": mc_event.on_event,
            "_exec": mc_builtin.execute_command,
            "help": lambda: tutorial(_agent.say, _world.show_title),
        }
    )
