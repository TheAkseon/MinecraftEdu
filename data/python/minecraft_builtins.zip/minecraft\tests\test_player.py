import unittest

from .support import command_result, debug_records

import minecraft._builtins as mc_builtin
import minecraft.event as mc_event

from minecraft.player import Player


class TestPlayer(unittest.TestCase):
    def test_say(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().say("hello", "world")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("execute", records[0].args[1])
        self.assertEqual(("@s", "~ ~ ~", "say", "hello world"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_say_as(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player("Steve").say("hello", "world")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("execute", records[0].args[1])
        self.assertEqual(
            ('@p[name="Steve"]', "~ ~ ~", "say", "hello world"), records[0].args[2]
        )
        self.assertEqual("wait", records[1].args[0])

    def test_give(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().give("STONE", 100)
            Player().give("DIAMOND PICK AXE", 1, 5)
            Player().give("DIAMOND PICK AXE", 1, 12)
        self.assertEqual(6, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("give", records[0].args[1])
        self.assertEqual(("@s", "stone", 100, 0, ""), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

        self.assertEqual("execute_command", records[2].args[0])
        self.assertEqual("replaceitem", records[2].args[1])
        self.assertEqual(
            ("entity", "@s", "slot.hotbar", 5, "diamond_pickaxe", 1, 0, ""),
            records[2].args[2],
        )
        self.assertEqual("wait", records[3].args[0])

        self.assertEqual("execute_command", records[4].args[0])
        self.assertEqual("replaceitem", records[4].args[1])
        self.assertEqual(
            ("entity", "@s", "slot.inventory", 3, "diamond_pickaxe", 1, 0, ""),
            records[4].args[2],
        )
        self.assertEqual("wait", records[5].args[0])

    def test_clear_inventory(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().clear_inventory()
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("clear", records[0].args[1])
        self.assertEqual("@s", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_teleport(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().teleport((10, 10, 10))
            Player().teleport("~10 10 -10")
            Player().teleport((0, 0, 0), (10, 10, 10))
            Player().look_at((10, 10, 10))
        self.assertEqual(8, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("teleport", records[0].args[1])
        self.assertEqual("teleport", records[2].args[1])
        self.assertEqual("teleport", records[4].args[1])
        self.assertEqual("teleport", records[6].args[1])
        self.assertEqual(("@s", "10 10 10"), records[0].args[2])
        self.assertEqual(("@s", "~10 10 -10"), records[2].args[2])
        self.assertEqual(("@s", "0 0 0", "facing", "10 10 10"), records[4].args[2])
        self.assertEqual(("@s", "~ ~ ~", "facing", "10 10 10"), records[6].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("wait", records[3].args[0])
        self.assertEqual("wait", records[5].args[0])
        self.assertEqual("wait", records[7].args[0])

    def test_turn(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().turn("LEFT")
            Player().turn("RIGHT")
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("teleport", records[0].args[1])
        self.assertEqual("teleport", records[2].args[1])
        self.assertEqual(("@s", "~ ~ ~", "facing", "^-1 ^ ^"), records[0].args[2])
        self.assertEqual(("@s", "~ ~ ~", "facing", "^1 ^ ^"), records[2].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("wait", records[3].args[0])

    def test_turn_directions_only(self):
        with self.assertRaises(mc_builtin.MinecraftError):
            Player().turn("FORWARD")

    def test_ability(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().ability("WORLDBUILDER")
            Player().ability("May Fly", False)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("ability", records[0].args[1])
        self.assertEqual("ability", records[2].args[1])
        self.assertEqual(("@s", "worldbuilder", True), records[0].args[2])
        self.assertEqual(("@s", "mayfly", False), records[2].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("wait", records[3].args[0])

    def test_gamemode(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().gamemode("survival")
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("gamemode", records[0].args[1])
        self.assertEqual(("survival", "@s"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_kill(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().kill()
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("kill", records[0].args[1])
        self.assertEqual("@s", records[0].args[2][0])
        self.assertEqual("wait", records[1].args[0])

    def test_clear_effect(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().clear_effect()
            Player().clear_effect("SPEED")
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("effect", records[0].args[1])
        self.assertEqual(("@s", "clear"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("effect", records[2].args[1])
        self.assertEqual(("@s", "speed", 0), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_add_effect(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().add_effect("SPEED")
            Player().add_effect("HASTE", 10, 10, True)
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("effect", records[0].args[1])
        self.assertEqual(("@s", "speed", 30, 0, False), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("effect", records[2].args[1])
        self.assertEqual(("@s", "haste", 10, 10, True), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_enchant(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().enchant("ARMOR FIRE", 100)
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("enchant", records[0].args[1])
        self.assertEqual(("@s", "ArmorFire", 100), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_give_experience(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().give_experience(10)
        self.assertEqual(2, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("experience", records[0].args[1])
        self.assertEqual((10, "@s"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])

    def test_give_clear_levels(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().give_levels(10)
            Player().clear_levels()
        self.assertEqual(4, len(records), records)
        self.assertEqual("execute_command", records[0].args[0])
        self.assertEqual("experience", records[0].args[1])
        self.assertEqual(("10L", "@s"), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual("experience", records[2].args[1])
        self.assertEqual(("-2147483648L", "@s"), records[2].args[2])
        self.assertEqual("wait", records[3].args[0])

    def test_show_clear_title(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().show_title("Title", "Subtitle", "Action Bar", 1, 2, 3)
            Player().clear_title()
        self.assertEqual(12, len(records), records)
        self.assertEqual(("execute_command", "title"), records[0].args[0:2])
        self.assertEqual(("execute_command", "title"), records[1].args[0:2])
        self.assertEqual(("execute_command", "title"), records[2].args[0:2])
        self.assertEqual(("execute_command", "title"), records[3].args[0:2])
        self.assertEqual(("execute_command", "title"), records[4].args[0:2])
        self.assertEqual(("@s", "reset"), records[0].args[2])
        self.assertEqual(("@s", "times", 1, 2, 3), records[1].args[2])
        self.assertEqual(("@s", "title", "Title"), records[2].args[2])
        self.assertEqual(("@s", "subtitle", "Subtitle"), records[3].args[2])
        self.assertEqual(("@s", "actionbar", "Action Bar"), records[4].args[2])
        self.assertEqual("wait", records[5].args[0])
        self.assertEqual("wait", records[6].args[0])
        self.assertEqual("wait", records[7].args[0])
        self.assertEqual("wait", records[8].args[0])
        self.assertEqual("wait", records[9].args[0])
        self.assertEqual(("execute_command", "title"), records[10].args[0:2])
        self.assertEqual(("@s", "clear"), records[10].args[2])
        self.assertEqual("wait", records[11].args[0])

    def test_play_sound(self):
        with debug_records(mc_builtin.COMMAND_LOG) as records:
            Player().play_sound("sound.name")
            Player().play_sound("sound.name", "10 10 10", 100, 100, 100)
        self.assertEqual(4, len(records), records)
        self.assertEqual(("execute_command", "playsound"), records[0].args[0:2])
        self.assertEqual(("sound.name", "@s", "~ ~ ~", 1, 1, 0), records[0].args[2])
        self.assertEqual("wait", records[1].args[0])
        self.assertEqual(("execute_command", "playsound"), records[2].args[0:2])
        self.assertEqual(
            ("sound.name", "@s", "10 10 10", 100, 100, 100), records[2].args[2]
        )
        self.assertEqual("wait", records[3].args[0])
