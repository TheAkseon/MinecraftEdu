"""Definitions of event mappings.
"""

from __future__ import annotations

import functools
import json
import logging

import minecraft._builtins as mc_builtin
import minecraft.enums as mc_enum
import minecraft.location as mc_loc

LOG = logging.getLogger("minecraft.event")

__all__ = [
    "add_listener",
    "AgentCommandEvent",
    "forever",
    "GenericEvent",
    "ItemEquippedEvent",
    "MobKilledEvent",
    "on_event",
    "PlayerTravelledEvent",
    "remove_listener",
    "BlockBrokenEvent",
    "BlockPlacedEvent",
    "CameraUsedEvent",
    "EndOfDayEvent",
    "EntitySpawnedEvent",
    "ItemAcquiredEvent",
    "ItemCraftedEvent",
    "ItemDroppedEvent",
    "ItemInteractedEvent",
    "ItemNamedEvent",
    "ItemSmeltedEvent",
    "ItemUsedEvent",
    "MobSpawnedEvent",
    "PlayerBouncedEvent",
    "PlayerDiedEvent",
    "PlayerMessageEvent",
    "PlayerTeleportedEvent",
]


class UnknownEventError(mc_builtin.MinecraftError):
    def __init__(self, message=None, event=None):
        if message:
            super().__init__(message)
        elif event:
            super().__init__("Event '{}' is not a known event".format(event))
        else:
            super().__init__("Unknown event")
        self.event = event


def make_event(event_name, handler):
    if event_name.startswith("on"):
        event_name = event_name[2:]

    try:
        name = mc_enum.Event.name_to_name(event_name)
    except mc_enum.UnknownEnumValueError:
        LOG.info("%s is not an event name", event_name)
        return

    # Import ourselves so we can getattr()
    import minecraft.event as mc_event

    return getattr(mc_event, "{}Event".format(name), GenericEvent)(name, handler)


def add_listener(event_name, handler):
    LOG.debug("%s(%r, %r)", "add_listener", event_name, handler)
    evt = make_event(event_name, handler)
    if not evt:
        raise UnknownEventError(event=event_name)
    evt.add()
    return evt


def remove_listener(handler):
    LOG.debug("%s(%r)", "remove_listener", handler)

    if isinstance(handler, str):
        mc_builtin.clear_callbacks(handler)
        return

    try:
        remove = handler.remove
    except AttributeError:
        LOG.error("Specified event is unknown")
    else:
        remove()


def on_event(func_or_name, func=None, *, add=True):
    """A decorator for functions to connect to events.

    Set add to false to define an event without enabling it yet.
    This is essential when defining events on methods.
    """

    def do_add(func):
        evt = make_event(func_or_name, func)
        if not evt:
            raise UnknownEventError(event=func_or_name)
        if add:
            evt.add()
        return evt

    return do_add(func) if func else do_add


class forever:
    """Run the function forever.
    
    When used as a function decorator, run the function repeatedly forever.
    """

    def __init__(self, func):
        self._func = func
        self.running = False
        self.stopped = False
        self.frequency = 0.1  # seconds between invocations
        functools.update_wrapper(self, func)
        mc_builtin.call_later(self.frequency, self)

    def __call__(self, *a, **kw):
        if self.running or self.stopped:
            return
        self.running = True
        try:
            self._func(*a, **kw)
        except Exception as ex:
            self.stopped = True
            print(ex)
            raise
        finally:
            self.running = False
        mc_builtin.call_later(self.frequency, self)

    def stop(self):
        self.stopped = True


def _get_agent_command_name(data):
    result = json.loads(data["properties"]["Result"])
    return result["commandName"]


def _get_agent_command_result(data):
    result = json.loads(data["properties"]["Result"])
    result.pop("commandName", None)
    if not result.pop("success", False):
        return {}
    return result


def _get_acquisition_method(data):
    return mc_enum.AcquisitionMethod.value_to_nice_name(
        data["properties"]["AcquisitionMethodID"]
    )


def _get_use_method(data):
    return mc_enum.UseMethod.value_to_nice_name(data["properties"]["ItemUseMethod"])


def _get_interact_method(data):
    return mc_enum.ItemInteractMethod.value_to_nice_name(data["properties"]["Method"])


def _get_aux_suffix(data, key):
    if not data or not key:
        return ""
    try:
        auxtype = data["properties"][key]
    except LookupError:
        return ""
    try:
        if auxtype and int(auxtype):
            return ":{}".format(auxtype)
    except (TypeError, ValueError):
        pass
    return ""


def _get_block_name(data):
    try:
        block = data["properties"]["Block"]
    except LookupError:
        block = None
    if block:
        try:
            ns = data["properties"]["Namespace"]
        except LookupError:
            pass
        else:
            if ns and ns != "minecraft":
                return "{}:{}".format(ns, block)
        return mc_enum.Block.name_to_nice_name(block)

    # Get block from Type/AuxType values instead
    block = mc_enum.Block.value_to_nice_name(data["properties"]["Type"])
    suffix = _get_aux_suffix(data, "AuxType")
    return block + suffix


def _get_block_placement_method(data):
    return mc_enum.BlockPlacementMethod.value_to_nice_name(
        data["properties"]["PlacementMethod"]
    )


def _get_cause(data):
    return mc_enum.ActorDamageCause.value_to_nice_name(data["properties"]["Cause"])


def _get_count(data):
    try:
        try:
            return int(data["measurements"]["Count"])
        except LookupError:
            return int(data["properties"]["Count"])
    except (TypeError, ValueError):
        pass


def _get_item_name(key, aux_key=None):
    def get_item_name(data):
        item = data["properties"][key]
        if not item or not int(item):
            return None
        suffix = _get_aux_suffix(data, aux_key)
        return mc_enum.Giveable.value_to_nice_name(item) + suffix

    return get_item_name


def _get_item_id(data):
    item = data["properties"]["Id"]
    suffix = _get_aux_suffix(data, "Aux")
    return mc_enum.Giveable.name_to_nice_name(item) + suffix


def _get_enchants(data):
    try:
        count = int(data["properties"]["ItemEnchantCount"])
    except (LookupError, ValueError, TypeError):
        return []

    enchants = {}
    for i in range(count):
        c = chr(ord("A") + i)
        e_type = mc_enum.Enchantment.value_to_nice_name(
            data["properties"]["ItemEnchantType" + c]
        )
        e_level = int(data["properties"]["ItemEnchantLevel" + c])
        if e_level >= 0:
            enchants[e_type] = e_level
    return enchants


def _get_mob_name(data):
    try:
        return mc_enum.Mob.value_to_nice_name(data["properties"]["MobType"])
    except LookupError:
        return None


def _get_mob_spawn_method(data):
    return mc_enum.MobSpawnMethod.value_to_nice_name(data["properties"]["SpawnType"])


def _get_location(data, prefix):
    return mc_loc.as_loc(
        data["measurements"][prefix + "X"],
        data["measurements"][prefix + "Y"],
        data["measurements"][prefix + "Z"],
    )


def _get_travel_method(data):
    return mc_enum.TravelMethod.value_to_nice_name(
        data["properties"]["TravelMethodType"]
    )


class _BaseEvent:
    def __init__(self, name, callback, bound_to=None):
        self.__evt_name = name
        self.__evt_id = None
        self.__evt_self = bound_to
        self.callback = callback
        functools.update_wrapper(self.callback, self)

    def add(self):
        self.__evt_id = mc_builtin.subscribe_callback(self.__evt_name, self._invoke)

    def remove(self):
        if self.__evt_id:
            mc_builtin.unsubscribe_callback(self.__evt_id)
            self.__evt_id = None

    def _invoke(self, response_body, *a, **kw):
        def convert(name_converter):
            name, converter = name_converter
            try:
                return converter(response_body)
            except Exception as ex:
                LOG.error("failed to convert '%s' because %s", name, ex, exc_info=True)

        args = tuple(map(convert, self._parameters))

        LOG.debug("Calling %r with %r", self.callback, args)
        if self.__evt_self:
            return self.callback(self.__evt_self, *args)
        return self.callback(*args)

    # Implement __get__ to allow events to be bound to class instances
    def __get__(self, inst, cls):
        if self.__evt_self or not inst:
            return self
        bound = type(self)(self.__evt_name, self.callback, inst)
        setattr(inst, self.callback.__name__, bound)
        return bound

    def __call__(self, *args, **kwargs):
        if self.__evt_self:
            return self.callback(self.__evt_self, *args, **kwargs)
        return self.callback(*args, **kwargs)

    def __repr__(self):
        return "<{}({})>".format(
            type(self).__name__, ", ".join(i[0] for i in self._parameters)
        )


class GenericEvent(_BaseEvent):
    _parameters = (("_response", lambda r: r),)


class AgentCommandEvent(_BaseEvent):
    _parameters = (
        ("command_name", _get_agent_command_name),
        ("result", _get_agent_command_result),
    )


class BlockBrokenEvent(_BaseEvent):
    _parameters = (
        ("block", _get_block_name),
        ("tool", _get_item_name("ToolItemType")),
        ("count", _get_count),
    )


class BlockPlacedEvent(_BaseEvent):
    _parameters = (
        ("block", _get_block_name),
        ("tool", _get_item_name("ToolItemType")),
        ("count", _get_count),
        ("method", _get_block_placement_method),
    )


class CameraUsedEvent(_BaseEvent):
    _parameters = (("selfie", lambda r: bool(r["properties"]["IsSelfie"])),)


class EndOfDayEvent(_BaseEvent):
    _parameters = ()


_ItemParameters = (("item", _get_item_name("Type", "AuxType")), ("count", _get_count))


class ItemAcquiredEvent(_BaseEvent):
    _parameters = _ItemParameters + (("method", _get_acquisition_method),)


class ItemCraftedEvent(_BaseEvent):
    _parameters = _ItemParameters


class ItemDroppedEvent(_BaseEvent):
    _parameters = _ItemParameters


class ItemEquippedEvent(_BaseEvent):
    _parameters = (
        ("item", _get_item_name("Type", "AuxType")),
        ("slot", lambda r: int(r["properties"]["Slot"])),
        ("enchants", _get_enchants),
    )


class ItemInteractedEvent(_BaseEvent):
    _parameters = (
        ("item", lambda r: str(r["properties"]["Id"])),
        ("count", lambda r: int(r["properties"]["Count"])),
        ("method", _get_interact_method),
    )


class ItemNamedEvent(_BaseEvent):
    _parameters = _ItemParameters[:1]


class ItemSmeltedEvent(_BaseEvent):
    _parameters = _ItemParameters[:1]


class ItemUsedEvent(_BaseEvent):
    _parameters = (("item", _get_item_id), ("method", _get_use_method))


class MobKilledEvent(_BaseEvent):
    _parameters = (
        ("mob", _get_mob_name),
        ("weapon", _get_item_name("WeaponType")),
        ("is_monster", lambda r: bool(r["properties"]["IsMonster"])),
    )


class EntitySpawnedEvent(_BaseEvent):
    _parameters = (("mob", _get_mob_name), ("spawner", _get_mob_spawn_method))


MobSpawnedEvent = EntitySpawnedEvent


class PlayerBouncedEvent(_BaseEvent):
    _parameters = (
        ("height", lambda r: float(r["measurements"]["BounceHeight"])),
        ("block", _get_block_name),
    )


class PlayerDiedEvent(_BaseEvent):
    _parameters = (("cause", _get_cause), ("mob", _get_mob_name))


class PlayerMessageEvent(_BaseEvent):
    _parameters = (
        ("message", lambda r: r["properties"]["Message"]),
        ("sender", lambda r: r["properties"]["Sender"]),
        ("receiver", lambda r: r["properties"].get("Receiver")),
        ("message_type", lambda r: r["properties"]["MessageType"]),
    )


class PlayerTeleportedEvent(_BaseEvent):
    _parameters = (("distance", lambda r: float(r["properties"]["MetersTravelled"])),)


class PlayerTravelledEvent(_BaseEvent):
    _parameters = (
        ("location", lambda r: _get_location(r, "PosAvg")),
        ("mode", _get_travel_method),
        ("distance", lambda r: float(r["measurements"]["MetersTravelled"])),
    )
