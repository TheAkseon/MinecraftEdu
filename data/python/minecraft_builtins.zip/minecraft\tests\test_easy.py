import logging
import unittest

from .support import log_records, debug_records

import minecraft._builtins as mc_builtin
import minecraft._easy as mc_easy
import minecraft.event as mc_event


class TestEasy(unittest.TestCase):
    def test_tutorial(self):
        actual = []
        expected = [
            f"title:{mc_easy.TUTORIAL[0]}",
            *[f"say:{t}" for t in mc_easy.TUTORIAL[1:]],
        ]

        tut = mc_easy.tutorial(
            lambda t: actual.append(f"say:{t}"),
            lambda t: actual.append(f"title:{t}"),
            lambda d, c: c(),
        )

        self.assertSequenceEqual(expected, actual)

    def test_easy_dict_overwrite(self):
        api = mc_easy.EasyAPIDict({"initial": None})

        with debug_records(mc_builtin.LOG) as records:
            api["not_initial"] = 123
        self.assertSequenceEqual([], records)

        with log_records(mc_builtin.LOG) as records:
            api["initial"] = 123
        self.assertEqual(1, len(records))
        r = records[0]
        self.assertEqual("WARNING", r.levelname)
        self.assertIn("initial", r.args)

    def test_easy_dict_event(self):
        listeners = []
        api = mc_easy.EasyAPIDict({"add_listener": lambda *a: listeners.append(a)})

        with log_records(mc_builtin.LOG, logging.WARNING) as records:
            api["on_an_event"] = lambda: None

        self.assertEqual(2, len(records))
        self.assertIn("on_an_event", records[0].args)

        self.assertEqual(1, len(listeners))
        evt = listeners[0]
        self.assertEqual("on_an_event", evt[0])

    def test_easy_forever_event(self):
        api = mc_easy.EasyAPIDict({})

        with debug_records(mc_builtin.CALLBACK_LOG) as records1:
            expected = mc_event.forever(lambda *a: None)
        with debug_records(mc_builtin.CALLBACK_LOG) as records2:
            api["all_the_time"] = expected

        self.assertEqual(1, len(records1), records1)
        self.assertIn("call_later", records1[0].args)
        self.assertIn(expected, records1[0].args)
        self.assertEqual([], records2)

        with debug_records(mc_builtin.CALLBACK_LOG) as records:
            expected()

        self.assertEqual(1, len(records))
        self.assertIn("call_later", records[0].args)
        self.assertIn(expected, records[0].args)
