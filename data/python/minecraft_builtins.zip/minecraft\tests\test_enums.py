import unittest

import minecraft.enums as mc_enums


class TestEnums(unittest.TestCase):
    def test_from_str(self):
        self.assertEqual("up", mc_enums.Direction.name_to_name("up"))
        self.assertEqual("up", mc_enums.Direction.name_to_name("UP"))
        self.assertEqual("up", mc_enums.Direction.name_to_name(" up "))

        self.assertEqual("diamond_ore", mc_enums.Block.name_to_name("Diamond Ore"))
        self.assertEqual("diamond_ore", mc_enums.Block.name_to_name("Diamond-Ore"))
        self.assertEqual("diamond_ore", mc_enums.Block.name_to_name("DIAMONDORE"))
        with self.assertRaises(NotImplementedError):
            mc_enums.Block.name_to_value("Diamond Ore")

        self.assertEqual("stone_slab2", mc_enums.Block.name_to_name("Stone Slab 2"))
        self.assertEqual("stone_slab3", mc_enums.Block.name_to_name("Stone Slab 3"))

        self.assertEqual("mooshroom", mc_enums.Mob.name_to_name("Mooshroom"))
        self.assertEqual("mooshroom", mc_enums.Mob.name_to_name("Mushroom Cow"))

        with self.assertRaises(mc_enums.UnknownEnumValueError):
            mc_enums.Direction.name_to_name("over")
        with self.assertRaises(mc_enums.UnknownEnumValueError):
            mc_enums.Direction.name_to_name("under")
        with self.assertRaises(mc_enums.UnknownEnumValueError):
            mc_enums.Direction.name_to_name("inside")

    def test_from_int(self):
        self.assertEqual("ArmorFire", mc_enums.Enchantment.value_to_name(1))
        self.assertEqual("WeaponUndead", mc_enums.Enchantment.value_to_name(10))
        self.assertEqual(
            mc_enums.Enchantment.value_to_name(10),
            mc_enums.Enchantment.value_to_name("10"),
        )

        self.assertEqual("diamond_ore", mc_enums.Block.value_to_name(56))
        self.assertEqual("mooshroom", mc_enums.Mob.value_to_name(16))

        self.assertEqual("stone_slab2", mc_enums.Block.value_to_name(182))

        with self.assertRaises(mc_enums.UnknownEnumValueError):
            mc_enums.Enchantment.value_to_name(100)

    def test_nice_name(self):
        self.assertEqual("up", mc_enums.Direction.name_to_nice_name("Up"))
        self.assertEqual("armor all", mc_enums.Enchantment.value_to_nice_name("0"))

        self.assertEqual("diamond ore", mc_enums.Block.value_to_nice_name(56))
        self.assertEqual("chicken", mc_enums.Mob.value_to_nice_name(10))
        self.assertEqual("mooshroom", mc_enums.Mob.value_to_nice_name(16))
        self.assertEqual("chest minecart", mc_enums.Item.value_to_nice_name(342))

    def test_giveable(self):
        self.assertEqual(
            "diamond_sword", mc_enums.Giveable.name_to_name("Diamond sword")
        )
        self.assertEqual("diamond_ore", mc_enums.Giveable.name_to_name("Diamond ore"))
        self.assertEqual("diamond_ore", mc_enums.Giveable.value_to_name(56))
        self.assertEqual("element_1", mc_enums.Giveable.value_to_name(-12))
        self.assertEqual("brick", mc_enums.Giveable.value_to_name(336))

    def test_nice_name_from_camel_case(self):
        for s, expect in [
            ("Name", "name"),
            ("TwoNames", "two names"),
            ("ThreeNameParts", "three name parts"),
            ("ALLCAPS", "allcaps"),
            ("nocaps", "nocaps"),
            ("MultipleCAPSInARow", "multiple caps in a row"),
        ]:
            actual = mc_enums._nice_from_camel_case([s])[s]
            self.assertEqual(actual, expect, s)
