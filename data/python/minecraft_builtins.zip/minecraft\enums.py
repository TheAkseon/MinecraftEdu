"""The enumerations used in Minecraft commands.

Both enum.Enum and enum.IntEnum are used with slightly different
semantics.

Enum is used for string mappings. The keys should be NICE_NAMES while
the values are the strings that the game engine sends and receives.

IntEnum is used for integer mappings. The keys should be the strings
that the game engine receives, while the values are the integers that
the game sends in responses.

Both types may be used with from_str() to convert user-provided strings
into the most similar value (ignoring punctuation, whitespace and case).
Access .name for the nice name or .value for the game engine name.

IntEnums may be used with from_int() to convert ints or numeric strings
into the enum value. Access .name for the nice name or .value for the
int.

nice_name() on any enum value will return a human friendly version of
the name field.
"""

from __future__ import annotations

import re as _re

import minecraft._builtins as _mc_builtin

class UnknownEnumValueError(_mc_builtin.MinecraftError):
    def __init__(self, enum_or_message, value=None, names=None):
        self.value = value
        if names:
            self.names = names
        else:
            names = getattr(enum_or_message, "_names", None)
            if names:
                self.names = list(names.values())
        if value:
            name = getattr(enum_or_message, "_name", None)
            if name:
                super().__init__("'{}' is not a known {}".format(value, name))
            else:
                super().__init__(enum_or_message, value)
        else:
            super().__init__(enum_or_message or "Unknown enum value")


def _norm(name):
    if not name:
        return name
    if not isinstance(name, str):
        raise TypeError("{!r} is not a string".format(name))
		
    norm_name = _re.sub("[^a-z0-9]", "", name, flags=_re.I)
    norm_name = _re.sub("user", "player", norm_name, flags=_re.I)
    norm_name = _re.sub("traveled", "travelled", norm_name, flags=_re.I)
    return norm_name.upper()


def _nice_from_camel_case(names):
    def repl(m):
        if m.group(2):
            return "{} {} {}".format(*m.groups())
        else:
            return "{} {}".format(m.group(1), m.group(3))

    return {k: _re.sub("([a-z0-9])([A-Z]*)([A-Z0-9])", repl, k).lower() for k in names}


class _EnumMeta(type):
    def __init__(self, name, bases, namespace):
        names = namespace.get("_names", {})
        values = namespace.get("_values", {})
        rvalues = namespace.get("_rvalues", {})
        nice_names = namespace.get("_nice_names", {})

        if names:
            if isinstance(names, (list, set, tuple)):
                names = {_norm(n): n for n in names}
        elif values:
            names = {_norm(n): n for n in values}
        elif rvalues:
            names = {_norm(n): n for n in rvalues}

        if values:
            values = {_norm(k): v for k, v in values.items()}
        if rvalues:
            rvalues = {k: _norm(v) for k, v in rvalues.items()}

        if values and not rvalues:
            rvalues = {v: k for k, v in values.items()}
        if not values and rvalues:
            values = {k: v for v, k in rvalues.items()}

        for k, v in namespace.items():
            if k.startswith("_"):
                continue
            if not isinstance(v, str):
                continue
            names[_norm(k)] = names[_norm(v)]

        self._names = names
        self._values = values
        self._rvalues = rvalues
        self._nice_names = nice_names
        self._name = namespace.get("_name", name.lower())

    def __dir__(self):
        return sorted(self._names)

    def __getattr__(self, attr):
        try:
            return self._names[attr]
        except LookupError:
            raise AttributeError(attr) from None

    def _init(self):
        pass

    def name_to_name(self, name):
        if not self._names:
            self._init()
        try:
            return self._names[_norm(name)]
        except LookupError:
            raise UnknownEnumValueError(self, name) from None

    def _name_to_nice_name(self, n):
        nn = self._nice_names.get(n)
        if not nn:
            self._nice_names[n] = nn = _re.sub("[\\-_]", " ", n).lower()
        return nn

    def name_to_nice_name(self, name):
        try:
            return self._name_to_nice_name(self.name_to_name(name))
        except _mc_builtin.MinecraftError:
            return name

    def name_to_value(self, name):
        if not self._values:
            self._init()
        return self._values.get(_norm(name))

    def value_to_name(self, value) -> str:
        if not self._rvalues:
            self._init()
        n = self._rvalues.get(int(value))
        if not n:
            raise UnknownEnumValueError(self, value)
        return self.name_to_name(n)

    def value_to_nice_name(self, value):
        n = self.value_to_name(int(value))
        if n:
            return self._name_to_nice_name(n)
        return f"#{value}"


class _DataComponentMixin:
    @classmethod
    def name_to_name_data_components(cls, name):
        data = 0
        components = ""
        if isinstance(name, tuple):
            if len(name) == 2:
                name, data = name
            elif len(name) == 3:
                name, data, components = name
        elif isinstance(name, str) and "#" in name[1:]:
            onlyname, _, rest = name.rpartition("#")
            if rest.startswith("{"):
                name, components = onlyname, rest
            else:
                try:
                    data = int(rest)
                    name = onlyname
                except (TypeError, ValueError):
                    pass
        return cls.name_to_name(name), data, components

    @classmethod
    def name_to_name_and_data(cls, name):
        return cls.name_to_name_data_components(name)[:2]

    @classmethod
    def name_to_name_only(cls, name):
        return cls.name_to_name_data_components(name)[0]


class Block(_DataComponentMixin, metaclass=_EnumMeta):
    @classmethod
    def _init(cls):
        bn = cls._names
        for k in _mc_builtin.get_block_names():
            alias = k.split(";")
            k1 = alias[0]
            bn.update({_norm(a): k1 for a in alias})
        # Ensure that "air" is available
        bn.setdefault(_norm("air"), "air")

    @classmethod
    def name_to_value(cls, name):
        raise NotImplementedError(f"{cls.__name__} does not support value lookup")

    @classmethod
    def value_to_name(cls, value):
        try:
            return _mc_builtin.get_block_name(int(value))
        except (LookupError, TypeError, ValueError):
            pass
        raise UnknownEnumValueError(cls, value)


class Item(_DataComponentMixin, metaclass=_EnumMeta):
    @classmethod
    def _init(cls):
        bn = cls._names
        for k in _mc_builtin.get_item_names():
            alias = k.split(";")
            k1 = alias[0]
            bn.update({_norm(a): k1 for a in alias})

    @classmethod
    def name_to_value(cls, name):
        raise NotImplementedError(f"{cls.__name__} does not support value lookup")

    @classmethod
    def value_to_name(cls, value):
        try:
            v = int(value)
            # Item ids are 256 or higher - otherwise, it's a block id
            if v >= 256:
                return _mc_builtin.get_item_name(v)
        except (LookupError, TypeError, ValueError):
            pass
        raise UnknownEnumValueError(cls, value)


class Giveable(_DataComponentMixin, metaclass=_EnumMeta):
    _name = "giveable item"

    @classmethod
    def name_to_name(cls, name):
        n = _norm(name)
        try:
            return Block.name_to_name(n)
        except _mc_builtin.MinecraftError:
            pass
        try:
            return Item.name_to_name(n)
        except _mc_builtin.MinecraftError:
            pass
        raise UnknownEnumValueError(cls, name)

    @classmethod
    def name_to_value(cls, name):
        raise NotImplementedError(f"{cls.__name__} does not support value lookup")

    @classmethod
    def value_to_name(cls, value):
        try:
            return _mc_builtin.get_item_name(int(value))
        except (LookupError, TypeError, ValueError):
            pass
        raise UnknownEnumValueError(cls, value)


class Mob(metaclass=_EnumMeta):
    @classmethod
    def _init(cls):
        bn = cls._names
        for k in _mc_builtin.get_mob_names():
            alias = k.split(";")
            k1 = alias[0]
            bn.update({_norm(a): k1 for a in alias})

    @classmethod
    def name_to_value(cls, name):
        raise NotImplementedError(f"{cls.__name__} does not support value lookup")

    @classmethod
    def value_to_name(cls, value):
        return _mc_builtin.get_mob_name(value)


class Direction(metaclass=_EnumMeta):
    _names = ["forward", "back", "left", "right", "up", "down"]
    forwards = "forward"
    backward = backwards = "back"


class TurnDirection(metaclass=_EnumMeta):
    _name = "turn direction"
    _names = ["left", "right"]


class Event(metaclass=_EnumMeta):
    _names = [
        "AgentCommand",
        "BlockBroken",
        "BlockPlaced",
        "CameraUsed",
        "EndOfDay",
        "EntitySpawned",
        "ItemAcquired",
        "ItemCrafted",
        "ItemDropped",
        "ItemEquipped",
        "ItemInteracted",
        "ItemNamed",
        "ItemSmelted",
        "ItemUsed",
        "MobKilled",
        "PlayerBounced",
        "PlayerDied",
        "PlayerMessage",
        "PlayerTeleported",
        "PlayerTravelled",
        # "PositionCommand",
        # "MultiplayerRoundEnd",
        # "MultiplayerRoundStart",
    ]
    MobSpawned = "EntitySpawned"


class Enchantment(metaclass=_EnumMeta):
    _values = {
        "ArmorAll": 0,
        "ArmorFire": 1,
        "ArmorFall": 2,
        "ArmorExplosive": 3,
        "ArmorProjectile": 4,
        "ArmorThorns": 5,
        "WaterBreath": 6,
        "WaterSpeed": 7,
        "WaterAffinity": 8,
        "WeaponDamage": 9,
        "WeaponUndead": 10,
        "WeaponArthropod": 11,
        "WeaponKnockback": 12,
        "WeaponFire": 13,
        "WeaponLoot": 14,
        "MiningEfficiency": 15,
        "MiningSilktouch": 16,
        "MiningDurability": 17,
        "MiningLoot": 18,
        "BowDamage": 19,
        "BowKnockback": 20,
        "BowFire": 21,
        "BowInfinity": 22,
        "FishingLoot": 23,
        "FishingLure": 24,
        "FrostWalker": 25,
        "Mending": 26,
        "CurseBinding": 27,
        "CurseVanishing": 28,
        "TridentImpaling": 29,
        "TridentRiptide": 30,
        "TridentLoyalty": 31,
        "TridentChanneling": 32,
        "CrossbowMultishot": 33,
        "CrossbowPiercing": 34,
        "CrossbowQuickcharge": 35,
        "Invalid": 37,
    }

    _nice_names = _nice_from_camel_case(_values)


class TravelMethod(metaclass=_EnumMeta):
    _name = "travel method"

    _values = {
        "Unknown": -1,
        "Walk": 0,
        "SwimWater": 1,
        "Fall": 2,
        "Climb": 3,
        "SwimLava": 4,
        "Fly": 5,
        "Riding": 6,
        "Sneak": 7,
        "Sprint": 8,
        "Bounce": 9,
        "FrostWalk": 10,
    }

    _nice_names = _nice_from_camel_case(_values)


class Effect(metaclass=_EnumMeta):
    _values = {
        "speed": 1,
        "slowness": 2,
        "haste": 3,
        "mining_fatigue": 4,
        "strength": 5,
        "instant_health": 6,
        "instant_damage": 7,
        "jump_boost": 8,
        "nausea": 9,
        "regeneration": 10,
        "resistance": 11,
        "fire_resistance": 12,
        "water_breathing": 13,
        "invisibility": 14,
        "blindness": 15,
        "night_vision": 16,
        "hunger": 17,
        "weakness": 18,
        "poison": 19,
        "wither": 20,
        "health_boost": 21,
        "absorption": 22,
        "saturation": 23,
        "levitation": 24,
        "fatal_poison": 25,
        "conduit_power": 26,
        "slow_falling": 27,
    }


class Ability(metaclass=_EnumMeta):
    _names = ["worldbuilder", "mayfly"]


class Difficulty(metaclass=_EnumMeta):
    _values = {"peaceful": 0, "easy": 1, "normal": 2, "hard": 3}


class GameMode(metaclass=_EnumMeta):
    _name = "game mode"
    _values = {"survival": 0, "creative": 1, "adventure": 2, "spectator": 3}


class GameRule(metaclass=_EnumMeta):
    _name = "game rule"
    _names = [
        "commandblockoutput",
        "dodaylightcycle",
        "doentitydrops",
        "dofiretick",
        "domobloot",
        "domobspawning",
        "dotiledrops",
        "doweathercycle",
        "drowningdamage",
        "falldamage",
        "firedamage",
        "keepinventory",
        "mobgriefing",
        "pvp",
        "showcoordinates",
        "naturalregeneration",
        "tntexplodes",
        "sendcommandfeedback",
        "doinsomnia",
        "commandblocksenabled",
        "randomtickspeed",
        "doimmediaterespawn",
        "showdeathmeassages",
        "functioncommandlimit",
        "allowdestructiveobjects",
        "allowmobs",
    ]


class MaskMode(metaclass=_EnumMeta):
    _name = "mask mode"
    _names = ["filtered", "masked", "replace"]


class CloneMode(metaclass=_EnumMeta):
    _name = "clone mode"
    _names = ["force", "move", "normal"]


class FillMode(metaclass=_EnumMeta):
    _name = "fill mode"
    _names = ["outline", "hollow", "destroy", "keep", "replace"]


class BlockReplaceMode(metaclass=_EnumMeta):
    _name = "replace mode"
    _names = ["destroy", "keep", "replace"]


class BlockPlacementMethod(metaclass=_EnumMeta):
    _name = "placement method"
    _values = {"Entity": 0, "Command": 1}


class AcquisitionMethod(metaclass=_EnumMeta):
    _name = "acquisition method"
    _values = {
        "Unknown": -1,
        "None": 0,
        "PickedUp": 1,
        "Crafted": 2,
        "TakenFromChest": 3,
        "TakenFromEnderchest": 4,
        "Bought": 5,
        "Anvil": 6,
        "Smelted": 7,
        "Brewed": 8,
        "Bottle": 9,
        "Trading": 10,
        "Fishing": 11,
    }

    _nice_names = _nice_from_camel_case(_values)


class ItemInteractMethod(metaclass=_EnumMeta):
    _name = "interact method"
    _values = {"Use": 0, "Place": 1}

    _nice_names = _nice_from_camel_case(_values)


class UseMethod(metaclass=_EnumMeta):
    _name = "use method"
    _values = {
        "Unknown": -1,
        "EquipArmor": 0,
        "Eat": 1,
        "Attack": 2,
        "Consume": 3,
        "Throw": 4,
        "Shoot": 5,
        "Place": 6,
        "FillBottle": 7,
        "FillBucket": 8,
        "PourBucket": 9,
        "UseTool": 10,
    }

    _nice_names = _nice_from_camel_case(_values)


class MobSpawnMethod(metaclass=_EnumMeta):
    _name = "mob spawn method"
    _values = {"Unknown": 0, "SpawnEgg": 1, "Command": 2, "Dispenser": 3, "Spawner": 4}

    _nice_names = _nice_from_camel_case(_values)


class ActorDamageCause(metaclass=_EnumMeta):
    _name = "damage cause"
    _values = {
        "None": -1,
        "Override": 0,
        "Contact": 1,
        "EntityAttack": 2,
        "Projectile": 3,
        "Suffocation": 4,
        "Fall": 5,
        "Fire": 6,
        "FireTick": 7,
        "Lava": 8,
        "Drowning": 9,
        "BlockExplosion": 10,
        "EntityExplosion": 11,
        "Void": 12,
        "Suicide": 13,
        "Magic": 14,
        "Wither": 15,
        "Starve": 16,
        "Anvil": 17,
        "Thorns": 18,
        "FallingBlock": 19,
        "Piston": 20,
        "FlyIntoWall": 21,
        "Magma": 22,
        "Fireworks": 23,
        "Lightning": 24,
        "Charging": 25,
        "All": 31,
    }

    _nice_names = _nice_from_camel_case(_values)


class MobSlot(metaclass=_EnumMeta):
    _name = "mob slot"
    _names = [
        "slot.armor.chest",
        "slot.armor.feet",
        "slot.armor.head",
        "slot.armor.legs",
        "slot.weapon.mainhand",
        "slot.weapon.offhand",
    ]
    chest = "slot.armor.chest"
    feet = "slot.armor.feet"
    head = "slot.armor.head"
    legs = "slot.armor.legs"
    weapon = "slot.weapon.mainhand"
    weapon2 = "slot.weapon.offhand"

class WeatherEffect(metaclass=_EnumMeta):
    _name = "weather effect"
    _values = {
        "clear": 0, 
        "rain": 1, 
        "thunder": 2
    }

class TimeSpec(metaclass=_EnumMeta):
    _name = "time spec"
    _values = {
        "day": 1000,
        "night": 13000,
        "noon": 6000,
        "midnight": 18000,
        "sunrise": 23000,
        "sunset": 12000
    }

class TimeQuery(metaclass=_EnumMeta):
    _name = "time query"
    _names = ["daytime", "gametime", "day"]
