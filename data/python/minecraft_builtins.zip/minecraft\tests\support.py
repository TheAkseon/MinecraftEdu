import contextlib
import logging
import unittest

import minecraft._builtins as mc_builtin


class LogCollector(logging.Handler):
    def __init__(self, min_level, max_level):
        super().__init__()
        self.records = []
        self.min_level = min_level
        self.max_level = max_level

    def emit(self, record):
        if self.min_level <= record.levelno <= self.max_level:
            self.records.append(record)

    def shouldFlush(self, record):
        return False

    def flush(self):
        pass


@contextlib.contextmanager
def log_records(log, max_level=logging.ERROR, min_level=logging.DEBUG):
    handler = LogCollector(min_level, max_level)
    log.addHandler(handler)
    try:
        yield handler.records
    finally:
        log.removeHandler(handler)


def debug_records(log):
    return log_records(log, logging.DEBUG, logging.DEBUG)


@contextlib.contextmanager
def command_result(command, body):
    if not hasattr(mc_builtin, "COMMAND_HANDLERS"):
        raise unittest.SkipTest("Mock builtins required for this test")
    old = mc_builtin.COMMAND_HANDLERS.pop(command, None)
    mc_builtin.COMMAND_HANDLERS[command] = lambda *a: {
        "header": {"messagePurpose": "commandResponse", "requestId": "0"},
        "body": body,
    }
    try:
        yield
    finally:
        if old:
            mc_builtin.COMMAND_HANDLERS[command] = old
        else:
            del mc_builtin.COMMAND_HANDLERS[command]
