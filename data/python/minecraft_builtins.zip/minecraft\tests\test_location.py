import unittest

from minecraft.location import Location, InvalidLocationError, from_me


class TestLocation(unittest.TestCase):
    # The CAN_PARSE and PARSED sets should be paired two ways:
    #  - every item in CAN_PARSE parses into the same index in PARSED
    #  - every pair of items parse into the same value

    CAN_PARSE = [
        (0, 0, 0),
        "0 0 0",
        ("~", "~", "~"),
        "~  ~  ~",
        ("^", "^", "^"),
        "^    ^      ^",
        ("~-2", "^+4", 6),
        "~-2 ^+4   6",
    ]

    PARSED = [
        Location(0.0, 0.0, 0.0),
        Location(0.0, 0.0, 0.0),
        Location((0.0, "~"), (0.0, "~"), (0.0, "~")),
        Location((0.0, "~"), (0.0, "~"), (0.0, "~")),
        Location((0.0, "^"), (0.0, "^"), (0.0, "^")),
        Location((0.0, "^"), (0.0, "^"), (0.0, "^")),
        Location((-2.0, "~"), (4.0, "^"), (6.0, None)),
        Location((-2.0, "~"), (4.0, "^"), (6.0, None)),
    ]

    def test_equality(self):
        # PARSED contains pairs of equal values, but they are
        # not the same objects, so they should all return equal
        for v1, v2 in zip(self.PARSED[::2], self.PARSED[1::2]):
            with self.subTest(v1):
                self.assertEqual(v1, v2)
                self.assertIsNot(v1, v2)

        # Comparing a Location to something that parses to a
        # location is also handled, but only when the left
        # hand side is the Location
        for v1, v2 in zip(self.PARSED, self.CAN_PARSE):
            with self.subTest(v2):
                self.assertEqual(v1, v2)

    def test_inequality(self):
        # PARSED contains pairs of equal values, so offsetting
        # by two should get us unequal values
        for v1, v2 in zip(self.PARSED[::2], self.PARSED[2::2]):
            with self.subTest(v2):
                self.assertNotEqual(v1, v2)

    def test_parse(self):
        # Check that parsing an already-parsed value passes
        # through the original object
        expected = Location(0, 0, 0)
        self.assertIs(expected, Location.parse(expected))

        for src, expect in zip(self.CAN_PARSE, self.PARSED):
            with self.subTest(src):
                self.assertEqual(expect, Location.parse(src))
            if isinstance(src, tuple):
                with self.subTest(repr(src).strip("()")):
                    self.assertEqual(expect, Location.parse(*src))

    def test_cannot_parse(self):
        for src in [
            "! 0 0",
            "* 0 0",
            "- 0 0" "0 0 *",
            "1 2 3 4",
            "2.3.4 3.4.5 4.5.6",
            "not a location",
        ]:
            with self.subTest(src):
                with self.assertRaises(InvalidLocationError):
                    Location.parse(src)

    def test_str(self):
        self.assertEqual("0 0 0", str(Location(0, 0, 0)))
        self.assertEqual("~ 0 0", str(Location("~", 0, 0)))
        self.assertEqual("0 ~ 0", str(Location(0, "~", 0)))
        self.assertEqual("0 0 ~", str(Location(0, 0, "~")))
        self.assertEqual("~-1 0 0", str(Location("~-1", 0, 0)))
        self.assertEqual("0 ~-1 0", str(Location(0, "~-1", 0)))
        self.assertEqual("0 0 ~-1", str(Location(0, 0, "~-1")))

    def test_add_sub(self):
        add_value = Location(10, 10, 10)
        sub_value = Location(-10, -10, -10)
        for base, expect in [
            ("0 0 0", "10 10 10"),
            ("~ ~ ~", "~10 ~10 ~10"),
            ("^ ^ ^", "^10 ^10 ^10"),
            ("-10 -10 -10", "0 0 0"),
            ("~-10 ~-10 ~-10", "~ ~ ~"),
            ("^-10 ^-10 ^-10", "^ ^ ^"),
        ]:
            with self.subTest(base):
                self.assertEqual(
                    Location.parse(expect), Location.parse(base) + add_value
                )
                self.assertEqual(
                    Location.parse(expect), Location.parse(base) - sub_value
                )

    def test_mul_div(self):
        mul_value = 4
        div_value = 0.25
        for base, expect in [
            ("0 0 0", "0 0 0"),
            ("1 1 1", "4 4 4"),
            ("~ ~ ~", "~ ~ ~"),
            ("~1 ~1 ~1", "~4 ~4 ~4"),
            ("^ ^ ^", "^ ^ ^"),
            ("^1 ^1 ^1", "^4 ^4 ^4"),
            ("-10 -10 -10", "-40 -40 -40"),
            ("~-10 ~-10 ~-10", "~-40 ~-40 ~-40"),
            ("^-10 ^-10 ^-10", "^-40 ^-40 ^-40"),
        ]:
            with self.subTest(base):
                self.assertEqual(
                    Location.parse(expect), Location.parse(base) * mul_value
                )
                self.assertEqual(
                    Location.parse(expect), Location.parse(base) / div_value
                )
                self.assertEqual(
                    Location.parse(expect), Location.parse(base) // div_value
                )
