"""A tagged mob
"""

from __future__ import annotations

import logging
import typing
import uuid

from minecraft import enums
from minecraft._builtins import execute_command, MinecraftError
from minecraft.location import as_loc, LocationType


__all__ = ["Mob"]


LOG = logging.getLogger(__name__)


class Mob:
    def __init__(self, tag=None):
        self._tag = tag or uuid.uuid4().hex
        self._key = f'@e[tag="{tag}"]'

    @classmethod
    def find(
        cls,
        *types: enums.Mob,
        count: int = None,
        radius: typing.Union[float, typing.Tuple[float, float]] = None,
        position: LocationType = None,
    ) -> typing.Optional[Mob]:
        tag = uuid.uuid4().hex
        if not radius and not count:
            count = 1
        selectors = [
            "c={}".format(count) if count else None,
            "rm={0[0]},r={0[1]}".format(radius) if isinstance(radius, tuple) else None,
            "r={}".format(radius) if radius and not isinstance(radius, tuple) else None,
        ]
        if position:
            loc = as_loc(position)
            selectors.extend(
                [
                    "x={}{}".format(loc.x_rel or "", loc.x),
                    "y={}{}".format(loc.y_rel or "", loc.y),
                    "z={}{}".format(loc.z_rel or "", loc.z),
                ]
            )
        for kind in types:
            if kind.startswith("!"):
                selectors.append("type=!" + enums.Mob.name_to_name(kind[1:]))
            else:
                selectors.append("type=" + enums.Mob.name_to_name(kind))
        selector = "@e[{}]".format(",".join(filter(None, selectors)))
        try:
            execute_command("tag", selector, "add", tag).wait()
        except MinecraftError:
            LOG.error("Failed to tag mobs", exc_info=True)
            return None
        return Mob(tag)

    def kill(self):
        """Kills the mobs.
        """
        execute_command("kill", self._key).wait()

    def teleport(self, location: LocationType):
        """Teleports the mobs to a new location.
        """
        execute_command("teleport", self._key, *as_loc(location)).wait()

    def give(self, item: enums.Item, slot: enums.MobSlot = "weapon"):
        """Gives the mobs a particular item.
        """
        execute_command(
            "replaceitem",
            "entity",
            self._key,
            enums.MobSlot.name_to_name(slot),
            0,
            enums.Item.name_to_name(item),
            1,
        ).wait()
